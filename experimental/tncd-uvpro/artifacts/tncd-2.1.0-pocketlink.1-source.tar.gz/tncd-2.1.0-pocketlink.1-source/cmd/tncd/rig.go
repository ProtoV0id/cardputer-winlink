package main

import (
	"flag"
	"fmt"
	"os"
	"strconv"
	"time"

	"github.com/ben-kuhn/tncd/v2/benshi"
	"github.com/ben-kuhn/tncd/v2/internal/bridge"
	"github.com/ben-kuhn/tncd/v2/internal/config"
	"github.com/ben-kuhn/tncd/v2/internal/rig"
	"github.com/ben-kuhn/tncd/v2/kiss"
)

// parseRigArgs validates the `tncd rig` verb and its argument.
//
// Frequencies are Hz only. Accepting MHz would make "145.03" and "145030000"
// both plausible, and a silent factor-of-a-million error keys a transmitter on
// the wrong band -- so ParseUint (not ParseFloat) is the whole guard.
func parseRigArgs(args []string) (string, uint32, error) {
	if len(args) == 0 {
		return "", 0, fmt.Errorf("rig: need one of get-freq, set-freq <hz>, teardown, probe, session-hold [seconds]")
	}
	switch args[0] {
	case "get-freq", "teardown", "probe", "session-acquire":
		return args[0], 0, nil
	case "session-set":
		// Three explicit values rather than a single opaque blob, so an
		// operator can read the line session-acquire printed and see what it
		// is about to do to their radio before pasting it.
		if len(args) != 4 {
			return "", 0, fmt.Errorf("rig session-set: need CHANNEL_A DUAL_WATCH APRS " +
				"(e.g. \"5 1 on\"), as printed by session-acquire")
		}
		if _, err := parseSnapshotArgs(args[1:]); err != nil {
			return "", 0, err
		}
		return "session-set", 0, nil
	case "session-hold":
		// Optional hold time in seconds. A session cannot span two
		// invocations -- what to restore lives in memory, by design, since a
		// state file could go stale or outlive the config that produced it --
		// so acquire, hold, and release all happen here.
		if len(args) < 2 {
			return "session-hold", defaultSessionHoldSeconds, nil
		}
		secs, err := strconv.ParseUint(args[1], 10, 16)
		if err != nil || secs == 0 {
			return "", 0, fmt.Errorf("rig session-hold: %q is not a number of seconds", args[1])
		}
		return "session-hold", uint32(secs), nil
	case "set-freq":
		if len(args) < 2 {
			return "", 0, fmt.Errorf("rig set-freq: need a frequency in Hz")
		}
		hz, err := strconv.ParseUint(args[1], 10, 32)
		if err != nil {
			return "", 0, fmt.Errorf("rig set-freq: %q is not a frequency in Hz", args[1])
		}
		return "set-freq", uint32(hz), nil
	default:
		return "", 0, fmt.Errorf("rig: unknown command %q", args[0])
	}
}

// buildRigTransport constructs pc's transport via internal/bridge's shared
// constructor. This one-shot CLI and the running bridge must agree on how a
// config.Port turns into a kiss.Transport, so bridge stays the single source
// of truth and this just calls its exported wrapper rather than
// reimplementing the type switch.
func buildRigTransport(pc config.Port) (kiss.Transport, error) {
	return bridge.BuildTransport(pc)
}

// runRig opens port n's transport and runs one Benshi rig command directly
// over it. It is a one-shot tool: it does not start the engine or any
// frontend, and it tears everything back down before returning.
//
// Every error names the port and the link that failed -- config, transport
// open, or the radio's own reply -- because this command's whole reason to
// exist is diagnosing hardware run against real, possibly-misbehaving
// radios. A bare "rig: timeout" tells the operator nothing about which of
// several links died.
func runRig(cfgPath string, port int, args []string) error {
	cmd, hz, err := parseRigArgs(args)
	if err != nil {
		return err
	}

	cfg, err := config.Load(cfgPath)
	if err != nil {
		return fmt.Errorf("rig: could not load config %q: %w", cfgPath, err)
	}
	if port < 0 || port >= len(cfg.Ports) {
		return fmt.Errorf("rig: port %d is not configured (config %q has %d port(s))", port, cfgPath, len(cfg.Ports))
	}

	tr, err := buildRigTransport(cfg.Ports[port])
	if err != nil {
		return fmt.Errorf("rig: port %d: could not build transport: %w", port, err)
	}
	if err := tr.Open(); err != nil {
		return fmt.Errorf("rig: port %d: transport open failed: %w", port, err)
	}
	defer tr.Close()

	// The Benshi (Gaia) command protocol does NOT get a channel of its own on
	// this hardware -- confirmed on a real UV-PRO 2026-09-23. It is served on
	// the SAME RFCOMM connection as KISS traffic ("SPP Dev"); a separate
	// "BS AOC" channel exists, accepts the connection, and answers nothing.
	// A Gaia request written straight to the KISS transport gets a real
	// reply (GET_DEV_INFO round-tripped on the bench), and KISS/Gaia frames
	// were shown to interleave cleanly on the wire (two independent KISS
	// frames plus a Gaia reply, all confirmed on-air by a separate Dire Wolf
	// receiver) -- the two protocols are told apart by their leading bytes
	// (KISS: 0xC0, Gaia: 0xFF 0x01), not by which socket they arrived on.
	// kiss.ControlChannelFor now reflects that: for a Bluetooth transport it
	// hands back a view of tr itself rather than dialling the silent "BS AOC"
	// channel, so this goes through the one real path instead of bypassing
	// it and calling rig.New(tr, ...) directly.
	//
	// This CLI is safe as-is because it is one-shot: nothing else is reading
	// this stream while rig.New's reader loop runs, so there is no framing
	// ambiguity to resolve. A future server-side integration that runs rig
	// control ALONGSIDE a live KISS port on the same transport is a
	// different problem -- it will need a demultiplexer (one reader owning
	// the byte stream, dispatching each frame to the KISS decoder or the
	// rig layer by its leading byte) in front of both consumers. Recorded
	// here rather than left to be rediscovered.
	cc, err := kiss.ControlChannelFor(tr)
	if err != nil {
		return fmt.Errorf("rig: port %d: no rig-control channel: %w", port, err)
	}
	defer cc.Close()

	r := rig.New(cc, 5*time.Second, cfg.Ports[port].VFOChannelMin)
	defer r.Close()

	switch cmd {
	case "get-freq":
		got, err := r.GetFreq()
		if err != nil {
			return fmt.Errorf("rig: port %d: get-freq: %w", port, err)
		}
		fmt.Println(got)
	case "set-freq":
		// Not "radio did not answer": SetFreq also refuses on purpose when
		// the radio is on a named memory or in dual watch, and reporting
		// those as a dead link would send the operator hunting the wrong
		// problem. The wrapped error says which it was.
		if err := r.SetFreq(hz); err != nil {
			return fmt.Errorf("rig: port %d: set-freq: %w", port, err)
		}
	case "teardown":
		// Teardown restores what THIS session's first set-freq displaced,
		// and each run of this one-shot command is its own session -- so it
		// only ever has something to restore when a set-freq preceded it in
		// the same invocation, which the CLI has no verb for. Say so plainly
		// rather than exiting 0 on a command that did nothing.
		restored, err := r.Teardown()
		if err != nil {
			return fmt.Errorf("rig: port %d: teardown: %w", port, err)
		}
		if !restored {
			fmt.Println("nothing to restore: no frequency was changed in this invocation " +
				"(use set-freq to tune the radio back by hand)")
		}
	case "session-hold":
		if err := runSessionHold(r, port, time.Duration(hz)*time.Second); err != nil {
			return err
		}
	case "session-acquire":
		if err := runSessionAcquire(r, port); err != nil {
			return err
		}
	case "session-set":
		snap, err := parseSnapshotArgs(args[1:])
		if err != nil {
			return err
		}
		if err := r.ApplySnapshot(snap); err != nil {
			return fmt.Errorf("rig: port %d: session-set: %w", port, err)
		}
		fmt.Printf("applied: %s\n", snap)
	case "probe":
		// Report what actually answered, not just that something did. The
		// old version printed a bare "radio answered" while README claimed
		// the command identifies the radio -- GET_DEV_INFO carries the
		// identification, it was simply being discarded.
		info, err := r.Probe()
		if err != nil {
			return fmt.Errorf("rig: port %d: probe: %w", port, err)
		}
		fmt.Printf("radio answered: %s\n", info)
	}
	return nil
}

// defaultSessionHoldSeconds is long enough to read the radio's front panel and
// see what changed, which is the point of the command.
const defaultSessionHoldSeconds = 15

// parseSnapshotArgs parses `session-set`'s three arguments. Validated before the
// radio is opened, so a typo costs nothing.
func parseSnapshotArgs(args []string) (rig.Snapshot, error) {
	var snap rig.Snapshot
	ch, err := strconv.ParseUint(args[0], 10, 8)
	if err != nil {
		return snap, fmt.Errorf("rig session-set: %q is not a channel index", args[0])
	}
	dw, err := strconv.ParseUint(args[1], 10, 8)
	if err != nil || dw > 2 {
		return snap, fmt.Errorf("rig session-set: %q is not a dual-watch value "+
			"(0 = off, 1 = side A, 2 = side B)", args[1])
	}
	var aprs bool
	switch args[2] {
	case "on":
		aprs = true
	case "off":
		aprs = false
	default:
		return snap, fmt.Errorf("rig session-set: %q is not \"on\" or \"off\"", args[2])
	}
	return rig.Snapshot{ChannelA: byte(ch), DoubleChannel: benshi.DoubleChannel(dw), APRS: aprs}, nil
}

// runSessionAcquire applies managed session settings and LEAVES THEM APPLIED.
//
// This exists because rig control and KISS share one link on these radios, so a
// process holding a session cannot coexist with a running tncd. Applying the
// settings and exiting lets the daemon take the link for a real on-air session.
//
// Settings reach the radio's NVRAM, so the radio stays configured after this
// exits -- a power cycle does not undo it. That is why the output states, in
// full, what has to be put back and how: nothing else is going to.
func runSessionAcquire(r *rig.Rig, port int) error {
	before, err := r.SessionSnapshot()
	if err != nil {
		return fmt.Errorf("rig: port %d: session-acquire: %w", port, err)
	}
	if err := r.AcquireSession(); err != nil {
		return fmt.Errorf("rig: port %d: session-acquire: %w", port, err)
	}
	after, err := r.SessionSnapshot()
	if err != nil {
		return fmt.Errorf("rig: port %d: session-acquire: reading back: %w", port, err)
	}
	fmt.Printf("session settings APPLIED and LEFT IN PLACE on port %d\n", port)
	fmt.Printf("  before: %s\n", before)
	fmt.Printf("  now:    %s\n", after)
	fmt.Println("These writes reach the radio's NVRAM: a power cycle will NOT undo them.")
	fmt.Printf("To put the radio back by hand:  tncd rig --port %d session-set %s\n", port, before.Args())
	return nil
}

// runSessionHold acquires managed session settings, holds them so the operator
// can see the radio change, and releases them.
//
// Acquire and release have to happen in ONE invocation: what to put back is held
// in memory by deliberate design, so a separate `session-release` process would
// have nothing to restore from. Holding in between is what makes this testable
// against real firmware -- the operator watches dual watch go off, the radio
// switch to VFO mode and APRS stop, then watches all three come back.
func runSessionHold(r *rig.Rig, port int, hold time.Duration) error {
	if err := r.AcquireSession(); err != nil {
		return fmt.Errorf("rig: port %d: session-hold: acquire: %w", port, err)
	}
	if hz, err := r.GetFreq(); err == nil {
		fmt.Printf("session acquired; radio on %d Hz -- holding %s\n", hz, hold)
	} else {
		fmt.Printf("session acquired -- holding %s\n", hold)
	}
	time.Sleep(hold)

	// Release even if the operator interrupts the wait, and report a failure
	// loudly: writes reach the radio's NVRAM, so an unreleased session leaves
	// the radio reconfigured until something puts it back.
	if err := r.ReleaseSession(); err != nil {
		return fmt.Errorf("rig: port %d: session-hold: release FAILED, the radio is still "+
			"in packet configuration: %w", port, err)
	}
	fmt.Println("session released; radio restored")
	return nil
}

// runRigCommand implements the "rig" subcommand: parse -c/--port and the verb,
// run it, and report failures with an exit code. It stays a thin wrapper
// around runRig so runRig itself -- the part with actual behavior -- takes
// plain arguments and is easy to call from a test without touching flag.
func runRigCommand(args []string) int {
	fs := flag.NewFlagSet("rig", flag.ContinueOnError)
	cfgFile := fs.String("c", "", "Configuration file (INI format)")
	fs.String("config", "", "Configuration file (INI format) (long form of -c)")
	port := fs.Int("port", 0, "Port number to control (index into [client.N] sections, default 0)")
	fs.Usage = func() {
		fmt.Fprintf(os.Stderr, "Usage: tncd rig -c FILE [--port N] get-freq|set-freq HZ|teardown|probe|session-hold [seconds]|session-acquire|session-set ...\n\n")
		fs.PrintDefaults()
	}
	if err := fs.Parse(args); err != nil {
		return 2
	}
	if longCfg := fs.Lookup("config").Value.String(); longCfg != "" && *cfgFile == "" {
		*cfgFile = longCfg
	}
	if *cfgFile == "" {
		fmt.Fprintln(os.Stderr, "rig: -c FILE is required")
		return 2
	}

	if err := runRig(*cfgFile, *port, fs.Args()); err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}
