// Package rig drives a Benshi-protocol radio over a control channel.
//
// Everything here runs OFF the engine goroutine. A Benshi command is a
// round-trip to the radio with a timeout, and the engine owns all L2 state, so
// blocking it would stall AX.25 on every port for the duration.
//
// This package does not restore the radio's original frequency when a
// session ends unless a caller explicitly asks it to (see (*Rig).Teardown).
// hamlib sets no precedent for doing so automatically either: rigctld leaves
// a radio wherever it was last tuned on disconnect, so "restore on exit" was
// never a requirement here, and this package does not fake one.
package rig

import (
	"errors"
	"fmt"
	"io"
	"log"
	"sync"
	"time"

	"github.com/ben-kuhn/tncd/v2/benshi"
)

// ErrTimeout reports a radio that did not answer within the configured timeout.
var ErrTimeout = errors.New("rig: radio did not reply in time")

// ErrClosed reports use of a rig whose channel has been closed.
var ErrClosed = errors.New("rig: control channel closed")

// quietPeriodMultiplier sets how long request() blocks -- still holding
// reqMu, so no other request can start -- after its own REPLY timeout,
// before letting the next request begin. See waitOutQuietPeriod. It does NOT
// apply to a write timeout, which poisons the rig instead -- see the
// write-timeout branch in request() for why that case is different.
//
// The Benshi protocol carries no per-message correlation id, so once a
// request's write has landed but its reply times out, a reply of that
// command type that shows up afterward cannot be attributed to the request
// it answers. Three earlier designs here tried to guess anyway -- matching
// by command type alone, then two FIFO-generation schemes -- and each guess
// was wrong in some real scenario: dropping the straggler loses a genuine
// answer when it was merely slow; delivering it to whatever is waiting next
// misattributes it when the straggler was for an earlier, abandoned request.
// The only way to make an unlabeled reply unambiguous is to guarantee at
// most one request is ever outstanding, so nothing else can possibly be
// waiting when a straggler shows up -- hence holding off the NEXT request
// instead of trying to match the stray reply.
//
// This works because a reply timeout only ever follows a COMPLETED write: at
// that point the byte stream's state is known, so a bounded wait for a
// straggler is safe. A write timeout has no such guarantee (see
// quietPeriodMultiplier's use in request()), which is why it isn't handled
// the same way.
//
// The trade-off here is added latency on the request immediately after a
// reply timeout. That's acceptable: timeouts are rare on a working link, and
// rig control (QSY) happens before connecting to a station, not mid-QSO, so
// a delayed poll costs nothing a user notices.
const quietPeriodMultiplier = 3

// Rig is a request/response session with one radio.
//
// One request is in flight at a time: the radio is a single serial endpoint
// and replies carry no correlation id, so concurrent requests could not be
// matched to their commands. After a request's reply times out (its write
// already landed), the NEXT request is held for a quiet period rather than
// started immediately -- see quietPeriodMultiplier -- so a straggler reply
// for the abandoned request can never be mistaken for the answer to a new
// one. After a request's WRITE times out (unknown whether anything reached
// the wire), the rig is poisoned instead: every later call fails with
// ErrClosed rather than risking a second write interleaving with the
// abandoned one, or a later request receiving its eventual stray reply.
// DefaultVFOChannelMin is the fallback for Rig's VFO floor. See
// SetFreq, and config.Port.VFOChannelMin for why it is configurable.
const DefaultVFOChannelMin = 251

type Rig struct {
	ch      io.ReadWriteCloser
	timeout time.Duration
	// vfoMin is the lowest channel id SetFreq will overwrite.
	vfoMin int

	// reqMu serializes whole request/response exchanges, including the
	// post-timeout quiet period -- that's what makes the period actually
	// block the next request rather than merely delaying its own return.
	reqMu sync.Mutex

	mu      sync.Mutex
	waiting chan benshi.Message // non-nil while a request awaits its reply
	waitCmd benshi.Command

	// orig is the channel record the first SetFreq of this session
	// displaced, kept so Teardown can restore it verbatim.
	orig   benshi.RFCh
	origOK bool

	// sess is what AcquireSession displaced; see session.go.
	sess session

	// ident caches the one-time GET_DEV_INFO answer. See Identify.
	ident   benshi.DevInfo
	identOK bool

	closed    bool
	closeErr  error
	closeOnce sync.Once
	closedCh  chan struct{} // closed by Close to unblock in-flight requests and the quiet period
}

// New starts a rig on ch. The reader goroutine runs until Close.
func New(ch io.ReadWriteCloser, timeout time.Duration, vfoChannelMin int) *Rig {
	if vfoChannelMin <= 0 {
		vfoChannelMin = DefaultVFOChannelMin
	}
	r := &Rig{ch: ch, timeout: timeout, vfoMin: vfoChannelMin, closedCh: make(chan struct{})}
	go r.readLoop()
	return r
}

// Closed reports whether this rig has been shut down -- by an explicit
// Close, by a write-timeout self-poisoning, or by its reader loop exiting.
//
// Callers that CACHE a Rig must consult this: request() closes the rig on a
// write timeout, and a cache that only checks "is this the same link?" will
// otherwise hand out a permanently dead rig forever.
func (r *Rig) Closed() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.closed
}

// Close shuts the rig down and closes the underlying channel.
//
// closedCh is closed before the channel itself so any request blocked in its
// select -- or waiting out a post-timeout quiet period -- wakes immediately
// instead of waiting out its full duration. closeErr is stored on the struct
// rather than a local var: sync.Once blocks concurrent callers until the
// winning call to f returns, which is exactly the happens-before guarantee
// needed to let every caller -- not just the one that ran f -- read the real
// result instead of a zero-value nil.
func (r *Rig) Close() error {
	r.closeOnce.Do(func() {
		r.mu.Lock()
		r.closed = true
		r.mu.Unlock()
		close(r.closedCh)
		r.closeErr = r.ch.Close()
	})
	return r.closeErr
}

// ErrDualWatch reports a radio in dual-watch mode, where which VFO carries a
// transmission is not derivable from the settings record.
var ErrDualWatch = errors.New("rig: radio is in dual-watch mode; turn dual watch off before tuning")

// ErrChannelMode reports a radio parked on a named memory channel rather than
// on its VFO.
var ErrChannelMode = errors.New("rig: radio is on a named memory channel, not its VFO")

// activeChannel resolves which channel record the radio actually transmits on,
// and reads it.
//
// Settings.channel_a is the sole authority, and GET_HT_STATUS's curr_ch_id is
// deliberately not consulted at all. Measured 2026-10-01 against the front
// panel, curr_ch_id disagreed with channel_a in both states where the two
// could differ, and channel_a was right every time:
//
//   - dual watch on: curr_ch_id read 1 whichever side was selected, while
//     channel_a/channel_b correctly named both sides.
//   - radio parked on memory 5 ("AUS 730", 145.730, confirmed on the panel and
//     by READ_RF_CH): channel_a read 5, curr_ch_id stayed 252 -- the VFO
//     scratch record -- and had not caught up 5s later.
//
// An earlier version cross-checked the two and refused on disagreement. That
// made every QSY *and* every GetFreq fail on a radio sitting on a memory
// channel, which is the common case this code most needs to handle, and it
// masked the ErrChannelMode guard that gives the operator an actionable
// message. curr_ch_id is simply not a reliable report of the active channel on
// this firmware, so cross-checking against it can only manufacture false
// refusals.
func (r *Rig) activeChannel() (benshi.RFCh, error) {
	sb, err := r.request(benshi.CmdReadSettings, nil)
	if err != nil {
		return benshi.RFCh{}, err
	}
	set, err := benshi.DecodeSettings(sb)
	if err != nil {
		return benshi.RFCh{}, err
	}
	id, ok := set.ActiveChannel()
	if !ok {
		return benshi.RFCh{}, ErrDualWatch
	}
	// Dual watch being on is not a reason to refuse: the selected side is
	// readable, so the target record is unambiguous. It IS worth warning
	// about. Dual watch time-slices the receiver between two frequencies, so
	// the other side's traffic can eat part or all of an inbound packet
	// whichever side is selected -- tuning the right channel on a radio that
	// will then drop frames is worth saying out loud. Turning it off for the
	// duration belongs to the session-settings work, not here.
	if set.DoubleChannel != benshi.DoubleChannelOff {
		log.Printf("rig: dual watch is on (side %s selected) -- the QSY applies correctly, "+
			"but packet will drop frames while the receiver is shared with the other side; "+
			"turn dual watch off for packet operation",
			dualWatchSideName(set.DoubleChannel))
	}
	return r.readChannel(id)
}

// SetFreq tunes the radio's active VFO to hz simplex.
//
// It does this by rewriting the channel record the active VFO points at,
// because these radios have no separate scratch frequency register: a VFO is
// an index into the channel table, and "frequency mode" is a VFO pointed at
// an unnamed record near the top of that table (252 on a UV-PRO, with 251 as
// its partner). FREQ_MODE_SET_PAR, which reads like the command for this and
// is what this package used to send, writes a different register that the
// firmware never promotes to the operating frequency -- proven on hardware by
// tuning the radio's dial and watching channel 252 follow it while
// FREQ_MODE_GET_STATUS kept reporting a stale value this code had written.
//
// Because the target is a real channel record, SetFreq refuses rather than
// writes in three cases: dual watch on (which VFO transmits is unknowable),
// settings and live status disagreeing about the active channel, and -- the
// one that protects the operator's data -- a record carrying a NAME. A named
// record is a memory the operator programmed, which means the radio is in
// channel mode, not VFO mode; retuning it would silently destroy that memory.
// An unnamed record is a VFO scratch record and is fair game.
//
// The record is patched in place rather than rebuilt, so sub-audio,
// bandwidth, power flags, pre-emphasis bypass and any DMR fields survive the
// round trip untouched. v1 is simplex only, which is what Winlink RMS
// gateways need.
func (r *Rig) SetFreq(hz uint32) error {
	ch, err := r.activeChannel()
	if err != nil {
		return err
	}
	// Three independent guards, because each catches a case the others
	// miss and the cost of being wrong is destroying a memory channel on
	// the operator's physical radio, silently and permanently.
	//
	// 1. A NAME means the operator programmed this record, so the radio is
	//    on a memory, not its VFO.
	if name := ch.Name(); name != "" {
		return fmt.Errorf("%w: channel %d is %q -- switch the radio to VFO/frequency mode first",
			ErrChannelMode, ch.ID(), name)
	}
	// 2. An UNNAMED memory passes the name check but is still a memory. On
	//    a UV-PRO the VFOs are 251 and 252, above a memory bank starting at
	//    0, so an id floor separates them -- but other Benshi variants are
	//    not confirmed to number theirs the same way, which is why this is
	//    configurable and why the error says exactly what to set. Failing
	//    here costs an operator one config line; not checking costs them a
	//    memory channel.
	if int(ch.ID()) < r.vfoMin {
		return fmt.Errorf("%w: channel %d is below the VFO floor (%d), so it looks like a memory "+
			"channel rather than the VFO -- if this radio really does keep its VFO at channel %d, "+
			"set vfo_channel_min = %d for this port",
			ErrChannelMode, ch.ID(), r.vfoMin, ch.ID(), ch.ID())
	}
	// 3. A repeater split is certainly a memory, whatever its id or name,
	//    so this one holds on any model regardless of numbering. It also
	//    stops a simplex QSY from silently discarding an offset the
	//    operator set -- WithFreq writes rx = tx.
	if ch.TXFreqHz() != ch.RXFreqHz() {
		return fmt.Errorf("%w: channel %d has a split (tx %d, rx %d), so it is a memory channel, "+
			"not a VFO -- tuning it would discard the offset",
			ErrChannelMode, ch.ID(), ch.TXFreqHz(), ch.RXFreqHz())
	}
	r.rememberOriginal(ch)
	body, err := r.request(benshi.CmdWriteRFCh, ch.WithFreq(hz).Bytes())
	if err != nil {
		return err
	}
	if len(body) < 1 || body[0] != 0 {
		return fmt.Errorf("rig: radio rejected WRITE_RF_CH for channel %d", ch.ID())
	}
	return nil
}

// rememberOriginal records the first record SetFreq displaced this session, so
// Teardown can put the radio back exactly where the operator left it. Only the
// FIRST is kept: later SetFreqs in the same session are this code's own QSYs,
// and restoring one of those would strand the radio on a frequency the
// operator never chose.
func (r *Rig) rememberOriginal(ch benshi.RFCh) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.origOK {
		r.orig = ch
		r.origOK = true
	}
}

// GetFreq reads the frequency the radio's active VFO is tuned to.
//
// This reads the channel record the VFO points at, NOT FREQ_MODE_GET_STATUS.
// That command answers from a separate frequency-mode register which on real
// firmware can hold a value the radio is not operating on -- on the bench it
// reported a stale 145.670 MHz while the radio sat on 145.030 MHz, so
// trusting it means reporting a frequency the operator is not listening to.
func (r *Rig) GetFreq() (uint32, error) {
	ch, err := r.activeChannel()
	if err != nil {
		return 0, err
	}
	return ch.RXFreqHz(), nil
}

// Teardown puts the radio back on the frequency it was on before this
// session's first SetFreq, and reports whether there was anything to undo.
//
// This restores the saved ORIGINAL record rather than re-reading the radio:
// after SetFreq the radio's own record holds this code's QSY, so a
// read-then-write would be a no-op that merely looks like a restore. The
// earlier implementation did exactly that and was silently useless.
//
// Nothing to undo is not an error -- a session that never tuned has nothing
// to restore -- so callers get (false, nil) rather than a failure.
func (r *Rig) Teardown() (bool, error) {
	r.mu.Lock()
	orig, ok := r.orig, r.origOK
	r.mu.Unlock()
	if !ok {
		return false, nil
	}
	body, err := r.request(benshi.CmdWriteRFCh, orig.Bytes())
	if err != nil {
		return false, err
	}
	if len(body) < 1 || body[0] != 0 {
		return false, fmt.Errorf("rig: radio rejected WRITE_RF_CH restoring channel %d", orig.ID())
	}
	r.mu.Lock()
	r.origOK = false
	r.mu.Unlock()
	return true, nil
}

// htStatusTXBit is is_in_tx within the first Status byte. Status packs, MSB
// first: is_power_on, is_in_tx, is_sq, is_in_rx, double_channel(2), is_scan,
// is_radio -- so is_in_tx is bit 6.
const htStatusTXBit = 0x40

// SetPTT asks the radio to key or unkey via DO_PROG_FUNC(MAIN_PTT).
//
// **This does not work on the firmware it has been tested against, and the
// error it returns now says so.** Measured on a BTech UV-PRO (firmware 146)
// 2026-09-30: the radio accepts the command and never transmits. Confirmed
// two independent ways -- its own is_in_tx bit stays 0, and a TS-2000 on the
// same frequency stayed at its -54 noise floor, the same meter having peaked
// at +60 for a known-good UI frame minutes earlier.
//
// What the probing did settle is the body format. DO_PROG_FUNC's payload is
// benlink's PF record -- button_id(4) | action(4), then effect(8), two bytes.
// tncd previously sent ONE byte (the effect alone) and the radio REJECTED it
// with reply status 5 every time. Nobody noticed because this function
// discarded the reply body and reported only the transport error, so a
// rejected command looked like a success. Both are fixed here: the body is
// now well-formed (the radio answers status 0) and a non-zero status is
// returned as an error.
//
// It still does not transmit, and the reason is not that the radio cannot be
// keyed remotely -- it is that keying is not a command on this protocol.
// HTCommander's voice PTT streams PCM over a separate Bluetooth audio channel
// (`BluetoothClassicMacOS.instance.sendAudio`), which is why it enumerates
// mainPtt and never calls it; the radio keys because audio is arriving. tncd
// sees the same path advertised and drops it on every connect ("dropped audio
// profile 0000111e/0000111f" -- Handsfree and Handsfree AG).
//
// So the radio keys when given something to transmit, and tncd's packet TX
// already relies on exactly that. What has no mechanism here is "key with
// nothing to send", which is what rigctl's set_ptt asks for. Supporting it
// would mean holding an HFP channel open and streaming silence. See
// docs/followups.md #17.
//
// PFActionType's LOW_TO_HIGH/HIGH_TO_LOW are used for on/off, which means
// the protocol does have distinct press and release rather than the toggle
// this code previously assumed. That assumption cannot be retested until
// something keys, so internal/frontend/rigctl keeps its toggle-safe
// bookkeeping: pessimistic there costs a redundant un-key, optimistic costs
// a stuck transmitter.
func (r *Rig) SetPTT(on bool) error {
	action := byte(pfActionHighToLow)
	if on {
		action = pfActionLowToHigh
	}
	body, err := r.request(benshi.CmdDoProgFunc, []byte{action, byte(benshi.PFEffectMainPTT)})
	if err != nil {
		return err
	}
	if len(body) < 1 {
		return benshi.ErrShortBody
	}
	if body[0] != 0 {
		return fmt.Errorf("%w (DO_PROG_FUNC status %d)", benshi.ErrRadioRejected, body[0])
	}
	return nil
}

// PF action codes, the low nibble of DO_PROG_FUNC's first body byte. The high
// nibble is button_id, which measurably does not matter here -- 0-3 and 15
// were all accepted identically -- so it is left at 0.
const (
	pfActionLowToHigh = 0x06 // press
	pfActionHighToLow = 0x07 // release
)

// GetPTT reports whether the radio is currently transmitting.
func (r *Rig) GetPTT() (bool, error) {
	body, err := r.request(benshi.CmdGetHTStatus, nil)
	if err != nil {
		return false, err
	}
	if len(body) < 2 {
		return false, benshi.ErrShortBody
	}
	if body[0] != 0 {
		return false, fmt.Errorf("%w (GET_HT_STATUS status %d)", benshi.ErrRadioRejected, body[0])
	}
	return body[1]&htStatusTXBit != 0, nil
}

// getDevInfoRequestByte is GET_DEV_INFO's one-byte request body. It's a
// protocol-required literal, not a parameter we choose -- benlink's
// GetDevInfoBody hardcodes the same value 3, and it isn't documented what it
// means. Confirmed live: an empty body (what this package sent before this
// fix) gets no reply at all -- 10s of silence -- while this exact byte gets
// an immediate answer.
const getDevInfoRequestByte = 0x03

// Probe confirms the radio answers the protocol at all, so callers can fail
// with a clear message rather than a timeout on every later command.
func (r *Rig) Probe() (benshi.DevInfo, error) {
	body, err := r.request(benshi.CmdGetDevInfo, []byte{getDevInfoRequestByte})
	if err != nil {
		return benshi.DevInfo{}, err
	}
	return benshi.DecodeDevInfo(body)
}

// ErrNotBenshi reports a control channel that did not answer GET_DEV_INFO.
//
// It deliberately does NOT claim the radio is definitely not a Benshi one.
// The only symptom available is silence, and a wedged link is silent too --
// this project has bench-confirmed Bluetooth links that accept writes while
// nothing reaches the radio. Callers should say both things.
var ErrNotBenshi = errors.New("rig: radio did not answer GET_DEV_INFO")

// Identify probes the radio once and caches the answer for the life of this
// Rig, so repeated callers cost one round trip rather than one each.
//
// A capability-bit check was considered and rejected. GET_DEV_INFO carries
// support_vfo and channel_count, and neither means what its name suggests:
//
//   - support_vfo reads 0 on a UV-PRO (firmware 146) that operates in VFO
//     mode perfectly well. Gating on it would refuse a working radio.
//   - channel_count reads 30 on a radio whose VFO record is channel 252.
//     What it actually counts is unclear -- it is about the number the
//     operator has programmed, and also about the size of one bank, and
//     nothing here distinguishes those. What IS clear is that it is ~30
//     while the VFO sits at 252, so it cannot derive a VFO floor under any
//     of those readings, and a floor taken from it would sit far below the
//     memories it is supposed to protect.
//
// Answering the command at all is the only trustworthy signal.
func (r *Rig) Identify() (benshi.DevInfo, error) {
	r.mu.Lock()
	if r.identOK {
		d := r.ident
		r.mu.Unlock()
		return d, nil
	}
	r.mu.Unlock()

	d, err := r.Probe()
	if err != nil {
		return benshi.DevInfo{}, fmt.Errorf("%w (either this is not a Benshi radio, "+
			"or its control link is not passing data): %v", ErrNotBenshi, err)
	}
	r.mu.Lock()
	r.ident, r.identOK = d, true
	r.mu.Unlock()
	return d, nil
}

// request sends one command and waits for its reply.
func (r *Rig) request(cmd benshi.Command, body []byte) ([]byte, error) {
	r.reqMu.Lock()
	defer r.reqMu.Unlock()

	r.mu.Lock()
	if r.closed {
		r.mu.Unlock()
		return nil, ErrClosed
	}
	replyCh := make(chan benshi.Message, 1)
	r.waiting = replyCh
	r.waitCmd = cmd
	r.mu.Unlock()

	defer func() {
		r.mu.Lock()
		r.waiting = nil
		r.mu.Unlock()
	}()

	msg := benshi.Message{Group: benshi.GroupBasic, Command: cmd, Body: body}
	frame := benshi.Frame{Flags: benshi.FlagNone, Data: msg.Bytes()}
	raw := frame.Bytes()
	if raw == nil {
		return nil, fmt.Errorf("rig: command %d produced an unencodable frame", cmd)
	}

	deadline := time.NewTimer(r.timeout)
	defer deadline.Stop()

	// io.ReadWriteCloser has no deadline method, and a wedged Bluetooth SPP
	// socket is a documented failure mode here (see CLAUDE.md) that accepts
	// writes without ever delivering them -- so Write itself must be bounded,
	// not just the wait for a reply. writeErr is buffered so this goroutine
	// can never block trying to report a result nobody is listening for any
	// more, whether the deadline fires first or the rig is closed underneath
	// it.
	writeErr := make(chan error, 1)
	go func() {
		_, err := r.ch.Write(raw)
		writeErr <- err
	}()

	select {
	case err := <-writeErr:
		if err != nil {
			return nil, fmt.Errorf("rig: write: %w", err)
		}
	case <-deadline.C:
		// select picks uniformly at random when several cases are ready, so
		// a write that completed at the same instant the deadline fired can
		// land here -- and poisoning the rig for a write that actually
		// succeeded would permanently close a healthy session. Re-check
		// non-blockingly before taking the fatal branch.
		select {
		case err := <-writeErr:
			if err != nil {
				return nil, fmt.Errorf("rig: write: %w", err)
			}
			goto awaitReply
		default:
		}
		// A write timeout is fatal to the rig, not just to this request --
		// see the doc comment on quietPeriodMultiplier for why the quiet
		// period does not apply here. In short: we don't know whether any
		// bytes reached the wire, and a wedged-then-unwedged transport can
		// complete the abandoned write at any later, unbounded time, so
		// there's no finite window after which a straggler stops being
		// plausible (unlike a reply timeout, where the write is known to
		// have already landed). Letting a later request write into the same
		// stream risks interleaving bytes with whatever this write
		// eventually sends; letting a later request wait for a reply risks
		// receiving THIS write's answer instead of its own. Poisoning the
		// rig closes both doors: Close() here means every later call fails
		// fast with ErrClosed instead of touching the stream again, and any
		// eventual late reply lands on a wait channel nothing is listening
		// to (this request's own, already abandoned) rather than a live one.
		r.Close()
		return nil, ErrTimeout
	case <-r.closedCh:
		return nil, ErrClosed
	}

awaitReply:
	// Fresh budget for the reply. One timer shared across both phases meant
	// a write that used 4.9s of a 5s budget left the reply 0.1s and reported
	// a spurious ErrTimeout -- plus a 15s quiet period -- even though every
	// doc comment here describes the two as independent timeouts.
	if !deadline.Stop() {
		select {
		case <-deadline.C:
		default:
		}
	}
	deadline.Reset(r.timeout)

	select {
	case m := <-replyCh:
		return m.Body, nil
	case <-deadline.C:
		if r.waitOutQuietPeriod(replyCh) {
			return nil, ErrClosed
		}
		return nil, ErrTimeout
	case <-r.closedCh:
		return nil, ErrClosed
	}
}

// waitOutQuietPeriod blocks -- still holding reqMu, so no other request can
// start -- after this request's own REPLY timeout, giving a straggler reply
// room to show up and be harmlessly discarded before the next request is
// allowed to begin. See quietPeriodMultiplier for why this exists instead of
// trying to match the straggler to whichever request happens to be waiting
// later. It reports whether the rig was closed while waiting, so the caller
// can surface ErrClosed instead of ErrTimeout.
//
// Only used for a reply-phase timeout, where the write is known to have
// already landed on the wire. A write-phase timeout is handled separately,
// by poisoning the rig instead -- see the write-timeout branch in request()
// for why the two cases aren't the same.
//
// r.waiting still points at replyCh until request()'s deferred cleanup runs
// (after this returns), so dispatch keeps routing a late reply here exactly
// as it would for any other in-flight request -- this just reads and drops
// it instead of answering a caller with it. If it arrives, the barrier lifts
// immediately: once the straggler is accounted for there is nothing left to
// be ambiguous about, so there's no reason to wait out the rest of the
// window.
func (r *Rig) waitOutQuietPeriod(replyCh chan benshi.Message) (closed bool) {
	timer := time.NewTimer(r.timeout * quietPeriodMultiplier)
	defer timer.Stop()
	select {
	case <-replyCh: // straggler arrived and is discarded; nothing left to wait for
	case <-timer.C:
	case <-r.closedCh:
		closed = true
	}
	return
}

// readLoop decodes frames from the radio, routing replies to a waiting request
// and folding notifications into the cache.
// readLoop reads frames until the control channel fails.
//
// It closes the rig on the way out. Without that, a channel that EOFs (port
// teardown, a relink closing portControlChannel) left a Rig that could never
// receive a reply again but still reported itself open: every later request
// burned its full timeout PLUS the quiet period -- 20s per command -- instead
// of failing fast with ErrClosed.
func (r *Rig) readLoop() {
	defer r.Close()

	dec := benshi.NewDecoder()
	buf := make([]byte, 512)
	for {
		n, err := r.ch.Read(buf)
		if n > 0 {
			frames, derr := dec.Feed(buf[:n])
			if derr == nil {
				for _, f := range frames {
					r.dispatch(f)
				}
			}
		}
		if err != nil {
			return
		}
	}
}

func (r *Rig) dispatch(f benshi.Frame) {
	m, err := benshi.DecodeMessage(f.Data)
	if err != nil {
		return
	}
	if !m.IsReply {
		// Only a REPLY can answer a request. The codec already decodes this
		// from the top bit of the command word and the matcher below keys
		// only on the command id, so without this an unsolicited message
		// that happens to share the in-flight command's id would be handed
		// to the waiting caller and parsed as its answer -- feeding, among
		// other things, the channel-id cross-check that SetFreq's write
		// guard depends on.
		return
	}
	if m.Command == benshi.CmdEventNotification {
		// Event notifications are not replies to anything, so they must
		// never reach the reply matcher below. Nothing here consumes them:
		// the one that looked useful, the frequency-mode change (type 14),
		// reports the frequency-mode register rather than the channel record
		// the radio actually operates on, so caching it produced a
		// confidently wrong answer to "what frequency are we on".
		return
	}
	// At most one request is ever outstanding -- request() holds a quiet
	// period after its own timeout before letting the next one start (see
	// quietPeriodMultiplier) -- so matching purely by command type is safe:
	// whatever is currently waiting is the only thing this reply could
	// possibly be answering.
	r.mu.Lock()
	w, cmd := r.waiting, r.waitCmd
	r.mu.Unlock()
	if w != nil && m.Command == cmd {
		select {
		case w <- m:
		default:
		}
	}
}

// dualWatchSideName renders which side the operator has selected, for log
// messages. See benshi.Settings.ActiveChannel for the measured mapping.
func dualWatchSideName(d benshi.DoubleChannel) string {
	switch d {
	case benshi.DoubleChannelOff:
		// Only the warning path used to call this, where off never occurs, so
		// off fell through to "unknown". Snapshot reports every state.
		return "off"
	case benshi.DoubleChannelA:
		return "A"
	case benshi.DoubleChannelB:
		return "B"
	default:
		return "unknown"
	}
}
