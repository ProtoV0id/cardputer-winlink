package agwpe_test

import (
	"encoding/binary"
	"fmt"
	"net"
	"strings"
	"sync"
	"testing"
	"time"

	agwpepkg "github.com/ben-kuhn/tncd/v2/agwpe"
	"github.com/ben-kuhn/tncd/v2/ax25"
	l2pkg "github.com/ben-kuhn/tncd/v2/ax25/l2"
	"github.com/ben-kuhn/tncd/v2/internal/bridge"
	"github.com/ben-kuhn/tncd/v2/internal/config"
	"github.com/ben-kuhn/tncd/v2/internal/engine"
	frontend "github.com/ben-kuhn/tncd/v2/internal/frontend/agwpe"
	"github.com/ben-kuhn/tncd/v2/internal/netutil"
	"github.com/ben-kuhn/tncd/v2/kiss"
)

// --- test helpers ---

// testFrame holds a parsed AGWPE header plus its payload.
type testFrame struct {
	agwpepkg.Header
	Data []byte
}

// fakePort implements bridge.PortSender and records sent frames.
type fakePort struct {
	mu     sync.Mutex
	frames [][]byte
	online bool
}

func newFakePort(online bool) *fakePort { return &fakePort{online: online} }

func (p *fakePort) Send(raw []byte) {
	p.mu.Lock()
	defer p.mu.Unlock()
	cp := make([]byte, len(raw))
	copy(cp, raw)
	p.frames = append(p.frames, cp)
}

func (p *fakePort) SendCommand(_ uint8, _ []byte) {}

func (p *fakePort) Online() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.online
}

func (p *fakePort) getSent() [][]byte {
	p.mu.Lock()
	defer p.mu.Unlock()
	out := make([][]byte, len(p.frames))
	copy(out, p.frames)
	return out
}

// makeBridgeWithFakePort creates a Bridge with manually-wired L2 and fake ports.
func makeBridgeWithFakePort(t *testing.T, eng *engine.Engine, fps []*fakePort, cfgPorts []config.Port) *bridge.Bridge {
	t.Helper()
	cfg := &config.Config{
		Server: config.Server{MaxClients: 8, IdleTimeout: 0},
		AX25:   config.AX25{MaxWindow: 3, N2Retry: 10, T3Timeout: 0},
		Ports:  cfgPorts,
	}
	b := bridge.New(eng, cfg)
	params := make([]l2pkg.PortParams, len(fps))
	for i := range fps {
		params[i] = l2pkg.DeriveParams(1200, 3, 10, 0)
	}
	senders := make([]bridge.PortSender, len(fps))
	for i, fp := range fps {
		senders[i] = fp
	}
	bridge.InjectPorts(b, eng, params, senders)
	return b
}

// dialServe starts a Serve on a free port and returns the listener and a dialed connection.
func dialServe(t *testing.T, eng *engine.Engine, b *bridge.Bridge) (net.Listener, net.Conn) {
	t.Helper()
	ln, err := frontend.Serve(eng, b, "127.0.0.1", 0, netutil.Allowlist{})
	if err != nil {
		t.Fatalf("Serve: %v", err)
	}
	conn, err := net.DialTimeout("tcp", ln.Addr().String(), 2*time.Second)
	if err != nil {
		ln.Close()
		t.Fatalf("dial: %v", err)
	}
	return ln, conn
}

// writeFrame sends one AGWPE request frame over conn.
func writeFrame(t *testing.T, conn net.Conn, port uint8, kind byte, pid uint8, from, to string, data []byte) {
	t.Helper()
	pkt := agwpepkg.Build(port, kind, pid, from, to, data)
	conn.SetWriteDeadline(time.Now().Add(2 * time.Second))
	if _, err := conn.Write(pkt); err != nil {
		t.Fatalf("writeFrame %c: %v", kind, err)
	}
}

// readFull reads exactly len(buf) bytes.
func readFull(conn net.Conn, buf []byte) error {
	total := 0
	for total < len(buf) {
		n, err := conn.Read(buf[total:])
		total += n
		if err != nil {
			return err
		}
	}
	return nil
}

// readOneFrame reads exactly one AGWPE frame (header + payload) from conn.
func readOneFrame(t *testing.T, conn net.Conn) testFrame {
	t.Helper()
	conn.SetReadDeadline(time.Now().Add(3 * time.Second))
	hdrBuf := make([]byte, agwpepkg.HeaderSize)
	if err := readFull(conn, hdrBuf); err != nil {
		t.Fatalf("readOneFrame header: %v", err)
	}
	hdr, err := agwpepkg.ParseHeader(hdrBuf)
	if err != nil {
		t.Fatalf("readOneFrame parse: %v", err)
	}
	tf := testFrame{Header: hdr}
	if hdr.DataLen > 0 {
		tf.Data = make([]byte, hdr.DataLen)
		if err := readFull(conn, tf.Data); err != nil {
			t.Fatalf("readOneFrame payload: %v", err)
		}
	}
	return tf
}

// onLoop posts fn to the engine and blocks until it completes.
func onLoop(t *testing.T, e *engine.Engine, fn func()) {
	t.Helper()
	done := make(chan struct{})
	e.Do(func() { fn(); close(done) })
	select {
	case <-done:
	case <-time.After(3 * time.Second):
		t.Fatal("engine stalled")
	}
}

// decodeAX25Frames decodes raw AX.25 bytes (as stored by fakePort) into frames.
// The fakePort.Send receives raw AX.25 bytes (bridge.SendToKISS passes raw AX.25;
// the real kiss.Port.Send wraps in KISS, but fakePort stores AX.25 directly).
func decodeAX25Frames(rawFrames [][]byte) []*ax25.Frame {
	var all []*ax25.Frame
	for _, raw := range rawFrames {
		if f, err := ax25.Parse(raw); err == nil {
			all = append(all, f)
		}
	}
	return all
}

// waitForSABM polls fp until a SABM is found, or times out.
func waitForSABM(t *testing.T, fp *fakePort) *ax25.Frame {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		for _, f := range decodeAX25Frames(fp.getSent()) {
			if f.Type == ax25.SABM {
				return f
			}
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("SABM not received by fake port")
	return nil
}

// --- tests ---

// TestVersionR: 'R' → 8-byte payload 02 00 00 00 00 00 00 00.
func TestVersionR(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	writeFrame(t, conn, 0, 'R', 0, "", "", nil)
	resp := readOneFrame(t, conn)

	if resp.Kind != 'R' {
		t.Fatalf("kind = %c, want R", resp.Kind)
	}
	if len(resp.Data) != 8 {
		t.Fatalf("data len = %d, want 8", len(resp.Data))
	}
	want := []byte{0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
	for i, wb := range want {
		if resp.Data[i] != wb {
			t.Fatalf("data[%d] = 0x%02x, want 0x%02x", i, resp.Data[i], wb)
		}
	}
}

// TestPortInfoG: two configured ports → "2;Port 0;Port 1;".
func TestPortInfoG(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fps := []*fakePort{newFakePort(true), newFakePort(true)}
	b := makeBridgeWithFakePort(t, eng, fps, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
		{Name: "Port 1", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	writeFrame(t, conn, 0, 'G', 0, "", "", nil)
	resp := readOneFrame(t, conn)

	if resp.Kind != 'G' {
		t.Fatalf("kind = %c, want G", resp.Kind)
	}
	got := string(resp.Data)
	want := "2;Port 0;Port 1;"
	if got != want {
		t.Fatalf("payload = %q, want %q", got, want)
	}
}

// TestCapsG: tx_delay=40 → caps bytes 0,255,40,30,63,20,7,0 + uint32 0.
func TestCapsG(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	txDelay := 40
	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{
			Name:        "Port 0",
			Type:        "serial",
			Device:      "/dev/null",
			OTABaudrate: 1200,
			KISS:        kiss.Params{TXDelay: &txDelay},
		},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	writeFrame(t, conn, 0, 'g', 0, "", "", nil)
	resp := readOneFrame(t, conn)

	if resp.Kind != 'g' {
		t.Fatalf("kind = %c, want g", resp.Kind)
	}
	if len(resp.Data) != 12 {
		t.Fatalf("caps len = %d, want 12", len(resp.Data))
	}
	// baud=0, traffic=255, tx_delay=40, tx_tail=30, persist=63, slot_time=20, max_frame=7, active=0
	wantBytes := []byte{0, 255, 40, 30, 63, 20, 7, 0}
	for i, wb := range wantBytes {
		if resp.Data[i] != wb {
			t.Fatalf("caps[%d] = %d, want %d", i, resp.Data[i], wb)
		}
	}
	wantU32 := uint32(0)
	gotU32 := binary.LittleEndian.Uint32(resp.Data[8:12])
	if gotU32 != wantU32 {
		t.Fatalf("caps bytes_rcvd = %d, want 0", gotU32)
	}
}

// TestRegisterAndDuplicate: first 'X' → \x01; same call from second client → \x00.
func TestRegisterAndDuplicate(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn1 := dialServe(t, eng, b)
	defer ln.Close()
	defer conn1.Close()
	time.Sleep(20 * time.Millisecond)

	// First client registers N0CALL.
	writeFrame(t, conn1, 0, 'X', 0, "N0CALL", "", nil)
	resp1 := readOneFrame(t, conn1)

	if resp1.Kind != 'X' {
		t.Fatalf("resp1 kind = %c, want X", resp1.Kind)
	}
	if len(resp1.Data) == 0 || resp1.Data[0] != 0x01 {
		t.Fatalf("resp1 data[0] = 0x%02x, want 0x01 (success)", resp1.Data[0])
	}

	// Second client tries to register same call.
	conn2, err := net.DialTimeout("tcp", ln.Addr().String(), 2*time.Second)
	if err != nil {
		t.Fatalf("dial conn2: %v", err)
	}
	defer conn2.Close()
	time.Sleep(20 * time.Millisecond)

	writeFrame(t, conn2, 0, 'X', 0, "N0CALL", "", nil)
	resp2 := readOneFrame(t, conn2)

	if resp2.Kind != 'X' {
		t.Fatalf("resp2 kind = %c, want X", resp2.Kind)
	}
	if len(resp2.Data) == 0 || resp2.Data[0] != 0x00 {
		t.Fatalf("resp2 data[0] = 0x%02x, want 0x00 (duplicate rejection)", resp2.Data[0])
	}
}

// TestUnprotoM: 'M' → fake port receives KISS-wrapped UI frame with correct
// dst/src/PID/info.
func TestUnprotoM(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	info := []byte("HELLO WORLD")
	writeFrame(t, conn, 0, 'M', 0xF0, "N0CALL", "KU0HN-10", info)

	// Give engine time to process.
	deadline := time.Now().Add(2 * time.Second)
	var parsed *ax25.Frame
	for time.Now().Before(deadline) {
		for _, f := range decodeAX25Frames(fp.getSent()) {
			if f.Type == ax25.UI {
				parsed = f
				break
			}
		}
		if parsed != nil {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if parsed == nil {
		t.Fatal("no UI frame received by fake port")
	}

	if parsed.Dst.String() != "KU0HN-10" {
		t.Fatalf("dst = %q, want KU0HN-10", parsed.Dst.String())
	}
	if parsed.Src.String() != "N0CALL" {
		t.Fatalf("src = %q, want N0CALL", parsed.Src.String())
	}
	if parsed.PID != 0xF0 {
		t.Fatalf("PID = 0x%02x, want 0xF0", parsed.PID)
	}
	if string(parsed.Info) != string(info) {
		t.Fatalf("info = %q, want %q", string(parsed.Info), string(info))
	}
}

// TestConnectCFlow: 'C' → SABM on fake port; inject UA via bridge.OnKISSFrame
// → client reads 'C' frame with "*** CONNECTED With Station N0CALL-2\r".
func TestConnectCFlow(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	// Register the local call.
	writeFrame(t, conn, 0, 'X', 0, "KU0HN-10", "", nil)
	resp := readOneFrame(t, conn)
	if resp.Kind != 'X' || (len(resp.Data) > 0 && resp.Data[0] != 0x01) {
		t.Fatalf("X register failed: kind=%c data=%v", resp.Kind, resp.Data)
	}

	// Send connect request.
	writeFrame(t, conn, 0, 'C', 0, "KU0HN-10", "N0CALL-2", nil)

	// Wait for SABM at fake port.
	sabm := waitForSABM(t, fp)

	// Build UA response (swap src/dst, response frame).
	ua := &ax25.Frame{
		Dst:     sabm.Src,
		Src:     sabm.Dst,
		Type:    ax25.UA,
		PF:      sabm.PF,
		Command: false,
	}

	// Inject UA on engine loop.
	onLoop(t, eng, func() {
		b.OnKISSFrame(kiss.RXFrame{Port: 0, Data: ua.Bytes()})
	})

	// Read the 'C' connected notification.
	conn.SetReadDeadline(time.Now().Add(3 * time.Second))
	resp2 := readOneFrame(t, conn)

	if resp2.Kind != 'C' {
		t.Fatalf("expected C notification, got %c (data=%q)", resp2.Kind, string(resp2.Data))
	}
	wantMsg := "*** CONNECTED With Station N0CALL-2\r" // Dire Wolf server.c wording
	if string(resp2.Data) != wantMsg {
		t.Fatalf("connected msg = %q, want %q", string(resp2.Data), wantMsg)
	}
}

// TestConnectOfflinePortBusy: fake port Online()=false → immediate 'd' BUSY.
func TestConnectOfflinePortBusy(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(false) // offline!
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	writeFrame(t, conn, 0, 'C', 0, "KU0HN-10", "N0CALL-2", nil)
	resp := readOneFrame(t, conn)

	if resp.Kind != 'd' {
		t.Fatalf("expected 'd' BUSY, got %c", resp.Kind)
	}
	wantMsg := "*** BUSY From KU0HN-10\r"
	if string(resp.Data) != wantMsg {
		t.Fatalf("busy msg = %q, want %q", string(resp.Data), wantMsg)
	}
}

// TestYOutstanding: after 'C'+UA and two 'D' sends beyond window →
// 'Y' response counts unacked+queued.
func TestYOutstanding(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	// Use MaxWindow=1 so 2nd D frame goes into the queue.
	cfg := &config.Config{
		Server: config.Server{MaxClients: 8},
		AX25:   config.AX25{MaxWindow: 1, N2Retry: 10, T3Timeout: 0},
		Ports: []config.Port{
			{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
		},
	}
	b := bridge.New(eng, cfg)
	params := []l2pkg.PortParams{l2pkg.DeriveParams(1200, 1, 10, 0)}
	bridge.InjectPorts(b, eng, params, []bridge.PortSender{fp})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	// Register and connect.
	writeFrame(t, conn, 0, 'X', 0, "KU0HN-10", "", nil)
	readOneFrame(t, conn) // consume X response

	writeFrame(t, conn, 0, 'C', 0, "KU0HN-10", "N0CALL-2", nil)

	// Wait for SABM.
	sabm := waitForSABM(t, fp)

	// Inject UA.
	ua := &ax25.Frame{
		Dst:     sabm.Src,
		Src:     sabm.Dst,
		Type:    ax25.UA,
		PF:      sabm.PF,
		Command: false,
	}
	onLoop(t, eng, func() {
		b.OnKISSFrame(kiss.RXFrame{Port: 0, Data: ua.Bytes()})
	})

	// Read C notification.
	conn.SetReadDeadline(time.Now().Add(3 * time.Second))
	cResp := readOneFrame(t, conn)
	if cResp.Kind != 'C' {
		t.Fatalf("expected C, got %c", cResp.Kind)
	}

	// Send two D frames (MaxWindow=1, so only first goes OTA; second queues).
	writeFrame(t, conn, 0, 'D', 0xF0, "KU0HN-10", "N0CALL-2", []byte("hello"))
	writeFrame(t, conn, 0, 'D', 0xF0, "KU0HN-10", "N0CALL-2", []byte("world"))
	time.Sleep(80 * time.Millisecond) // let engine process D frames

	// Query Y — should be 2 (1 unacked + 1 queued).
	writeFrame(t, conn, 0, 'Y', 0, "KU0HN-10", "N0CALL-2", nil)
	yResp := readOneFrame(t, conn)

	if yResp.Kind != 'Y' {
		t.Fatalf("expected Y, got %c", yResp.Kind)
	}
	if len(yResp.Data) != 4 {
		t.Fatalf("Y data len = %d, want 4", len(yResp.Data))
	}
	count := binary.LittleEndian.Uint32(yResp.Data)
	if count != 2 {
		t.Fatalf("Y outstanding = %d, want 2", count)
	}
}

// TestOversizedPayloadCloses: header claiming DataLen 70000 → connection closed.
func TestOversizedPayloadCloses(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	// Build a header with DataLen = 70000 (> MaxPayload=65536).
	hdr := make([]byte, agwpepkg.HeaderSize)
	hdr[4] = 'R' // kind
	binary.LittleEndian.PutUint32(hdr[28:32], 70000)

	conn.SetWriteDeadline(time.Now().Add(2 * time.Second))
	conn.Write(hdr)

	// Server should close the connection.
	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	buf := make([]byte, 1)
	n, err := conn.Read(buf)
	if n != 0 || err == nil {
		t.Fatalf("expected connection closed, got n=%d err=%v", n, err)
	}
}

// TestConnectNonOwnerBusy: client A connects KU0HN-10→N0CALL-2 (injecting UA so
// state=Connected); client B sends 'C' for the same pair → B receives 'd' BUSY,
// no new SABM is sent, and A's session is untouched.
func TestConnectNonOwnerBusy(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, connA := dialServe(t, eng, b)
	defer ln.Close()
	defer connA.Close()
	time.Sleep(20 * time.Millisecond)

	// Client A: register and connect.
	writeFrame(t, connA, 0, 'X', 0, "KU0HN-10", "", nil)
	resp := readOneFrame(t, connA)
	if resp.Kind != 'X' || (len(resp.Data) > 0 && resp.Data[0] != 0x01) {
		t.Fatalf("A: X register failed: kind=%c data=%v", resp.Kind, resp.Data)
	}

	writeFrame(t, connA, 0, 'C', 0, "KU0HN-10", "N0CALL-2", nil)

	// Wait for SABM from A.
	sabm := waitForSABM(t, fp)

	// Inject UA so the session becomes Connected.
	ua := &ax25.Frame{
		Dst:     sabm.Src,
		Src:     sabm.Dst,
		Type:    ax25.UA,
		PF:      sabm.PF,
		Command: false,
	}
	onLoop(t, eng, func() {
		b.OnKISSFrame(kiss.RXFrame{Port: 0, Data: ua.Bytes()})
	})

	// Consume A's 'C' connected notification.
	connA.SetReadDeadline(time.Now().Add(3 * time.Second))
	cResp := readOneFrame(t, connA)
	if cResp.Kind != 'C' {
		t.Fatalf("A: expected C notification, got %c", cResp.Kind)
	}

	// Snapshot frame count before client B connects.
	framesBefore := len(fp.getSent())

	// Client B: dial in and send 'C' for the same pair.
	connB, err := net.DialTimeout("tcp", ln.Addr().String(), 2*time.Second)
	if err != nil {
		t.Fatalf("dial connB: %v", err)
	}
	defer connB.Close()
	time.Sleep(20 * time.Millisecond)

	writeFrame(t, connB, 0, 'C', 0, "KU0HN-10", "N0CALL-2", nil)

	// B must receive 'd' BUSY immediately.
	connB.SetReadDeadline(time.Now().Add(3 * time.Second))
	busyResp := readOneFrame(t, connB)
	if busyResp.Kind != 'd' {
		t.Fatalf("B: expected 'd' BUSY, got %c (data=%q)", busyResp.Kind, string(busyResp.Data))
	}
	wantMsg := "*** BUSY From KU0HN-10\r"
	if string(busyResp.Data) != wantMsg {
		t.Fatalf("B: busy msg = %q, want %q", string(busyResp.Data), wantMsg)
	}

	// No new SABM should have been sent after B's request.
	time.Sleep(50 * time.Millisecond)
	framesAfter := len(fp.getSent())
	if framesAfter != framesBefore {
		t.Fatalf("expected no new frames after B's BUSY (before=%d after=%d)", framesBefore, framesAfter)
	}

	// A's session must still be Connected and owned by A.
	var connState l2pkg.ConnState
	var connOwner interface{}
	onLoop(t, eng, func() {
		c := b.L2().Get(0, "KU0HN-10", "N0CALL-2")
		if c == nil {
			t.Errorf("L2 conn is nil after B's BUSY attempt")
			return
		}
		connState = c.State
		connOwner = c.Owner
	})
	if connState != l2pkg.Connected {
		t.Fatalf("A's conn state = %v, want Connected", connState)
	}
	// Owner must not be nil (still A's client handle).
	if connOwner == nil {
		t.Fatalf("A's conn Owner became nil after B's BUSY attempt")
	}
}

// TestViaCountOverflowNoPanic verifies that 'V' and 'v' frames declaring more
// via bytes than are present in the payload do not panic (I1).
func TestViaCountOverflowNoPanic(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	// 'V' frame: nVia=10 but only 5 bytes of via data follow (should not panic).
	writeFrame(t, conn, 0, 'V', 0xF0, "N0CALL", "KU0HN", []byte{10, 0, 0, 0, 0, 0})

	// 'v' frame: nVia=10 but only 5 bytes of via data follow (should not panic).
	writeFrame(t, conn, 0, 'v', 0, "N0CALL", "KU0HN", []byte{10, 0, 0, 0, 0, 0})

	// Send 'R' and verify the server is still alive (didn't crash).
	writeFrame(t, conn, 0, 'R', 0, "", "", nil)
	resp := readOneFrame(t, conn)
	if resp.Kind != 'R' {
		t.Fatalf("expected 'R' response after overflow frames, got %c (server crashed?)", resp.Kind)
	}
}

// TestPartialHeaderReassembly: write a 'R' request split into 3 TCP writes → still answered.
func TestPartialHeaderReassembly(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	// Build R frame and split into 3 writes.
	frame := agwpepkg.Build(0, 'R', 0, "", "", nil)
	part1 := frame[:5]
	part2 := frame[5:20]
	part3 := frame[20:]

	conn.SetWriteDeadline(time.Now().Add(2 * time.Second))
	conn.Write(part1)
	time.Sleep(5 * time.Millisecond)
	conn.Write(part2)
	time.Sleep(5 * time.Millisecond)
	conn.Write(part3)

	resp := readOneFrame(t, conn)
	if resp.Kind != 'R' {
		t.Fatalf("expected R response, got %c", resp.Kind)
	}
	if len(resp.Data) != 8 {
		t.Fatalf("version payload len = %d, want 8", len(resp.Data))
	}
}

// TestRegisterCallsignCap: a client may register at most 8 distinct
// callsigns; the 9th is rejected (0x00), re-registering a held call still
// succeeds, and a slot freed by 'x' can be reused.
func TestRegisterCallsignCap(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	// Register 8 distinct callsigns — all succeed (0x01).
	calls := []string{"AA0A", "BB1B", "CC2C", "DD3D", "EE4E", "FF5F", "GG6G", "HH7H"}
	for _, call := range calls {
		writeFrame(t, conn, 0, 'X', 0, call, "", nil)
		resp := readOneFrame(t, conn)
		if resp.Kind != 'X' || len(resp.Data) != 1 || resp.Data[0] != 0x01 {
			t.Fatalf("register %s: kind=%c data=% x, want X 01", call, resp.Kind, resp.Data)
		}
	}

	// 9th distinct registration → rejected with 0x00.
	writeFrame(t, conn, 0, 'X', 0, "II8I", "", nil)
	resp := readOneFrame(t, conn)
	if resp.Kind != 'X' || len(resp.Data) != 1 || resp.Data[0] != 0x00 {
		t.Fatalf("9th registration: kind=%c data=% x, want X 00", resp.Kind, resp.Data)
	}

	// Re-registering an already-held call is idempotent → still succeeds.
	writeFrame(t, conn, 0, 'X', 0, "AA0A", "", nil)
	resp = readOneFrame(t, conn)
	if resp.Kind != 'X' || len(resp.Data) != 1 || resp.Data[0] != 0x01 {
		t.Fatalf("re-register held call: kind=%c data=% x, want X 01", resp.Kind, resp.Data)
	}

	// Unregister one ('x' — no response), then the freed slot fits a new call.
	writeFrame(t, conn, 0, 'x', 0, "BB1B", "", nil)
	writeFrame(t, conn, 0, 'X', 0, "II8I", "", nil)
	resp = readOneFrame(t, conn)
	if resp.Kind != 'X' || len(resp.Data) != 1 || resp.Data[0] != 0x01 {
		t.Fatalf("register after unregister: kind=%c data=% x, want X 01", resp.Kind, resp.Data)
	}
}

// TestUnprotoViaDigipeaterCap: 'V' with >8 digipeaters is dropped (no UI on
// the air); exactly 8 digis still produces a UI frame with all 8.
func TestUnprotoViaDigipeaterCap(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	buildV := func(nVia int) []byte {
		data := []byte{byte(nVia)}
		for i := 0; i < nVia; i++ {
			entry := make([]byte, 10)
			copy(entry, fmt.Sprintf("WIDE%d", i%9+1))
			data = append(data, entry...)
		}
		return append(data, []byte("payload")...)
	}

	// 9 digis → dropped: nothing reaches the port.
	before := len(fp.getSent())
	writeFrame(t, conn, 0, 'V', 0, "N0CALL", "CQ", buildV(9))
	time.Sleep(150 * time.Millisecond)
	if got := len(fp.getSent()); got != before {
		t.Fatalf("9-digi 'V' produced %d port sends, want 0", got-before)
	}

	// 8 digis → one UI frame carrying all 8 via addresses.
	writeFrame(t, conn, 0, 'V', 0, "N0CALL", "CQ", buildV(8))
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		frames := decodeAX25Frames(fp.getSent())
		if len(frames) > 0 {
			f := frames[0]
			if f.Type != ax25.UI {
				t.Fatalf("frame type = %s, want UI", f.Type)
			}
			if len(f.Via) != 8 {
				t.Fatalf("via count = %d, want 8", len(f.Via))
			}
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("8-digi 'V' produced no UI frame")
}

// TestInflightCapClosesFloodingClient: with the engine loop stalled, a client
// that floods more frames than the inflight cap is disconnected by the server
// instead of growing the engine queue without bound.
func TestInflightCapClosesFloodingClient(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()

	// Wait for the client to register (its read loop only starts after the
	// engine processes AddClient).
	deadline := time.Now().Add(2 * time.Second)
	for {
		n := 0
		onLoop(t, eng, func() { n = len(b.Clients()) })
		if n == 1 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("client never registered")
		}
		time.Sleep(5 * time.Millisecond)
	}

	// Stall the engine loop so posted frames accumulate in flight.
	release := make(chan struct{})
	stalled := make(chan struct{})
	eng.Do(func() { close(stalled); <-release })
	select {
	case <-stalled:
	case <-time.After(2 * time.Second):
		t.Fatal("engine did not pick up blocker")
	}

	// Flood well past the cap of 256 in-flight frames.
	pkt := agwpepkg.Build(0, 'R', 0, "", "", nil)
	go func() {
		for i := 0; i < 4*256; i++ {
			if _, err := conn.Write(pkt); err != nil {
				return
			}
		}
	}()

	// The server must close the connection: our read eventually errors.
	conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, err := conn.Read(make([]byte, 1))
	close(release)
	if err == nil {
		t.Fatal("flooding client was not disconnected")
	}
}

// TestOutOfRangePortIsClampedNotDropped pins the behaviour that lets Xastir
// transmit at all.
//
// Xastir sends its position beacons as 'V' with port 255 even when configured
// for radio port 0. tncd used to validate the port and drop the frame, so every
// Xastir transmission vanished with only a log line and the client had no way to
// know. Dire Wolf, which Xastir is developed against, resets an out-of-range
// port to 0 and keeps going; matching that is what makes the two interoperable.
func TestOutOfRangePortIsClampedNotDropped(t *testing.T) {
	eng := engine.New()
	go eng.Run()
	defer eng.Stop()

	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})

	ln, conn := dialServe(t, eng, b)
	defer ln.Close()
	defer conn.Close()
	time.Sleep(20 * time.Millisecond)

	// Port 255 on a single-port station: the exact frame Xastir sends.
	writeFrame(t, conn, 255, 'M', 0xF0, "KU0HN-2", "APX222", []byte("beacon"))

	deadline := time.Now().Add(2 * time.Second)
	var parsed *ax25.Frame
	for time.Now().Before(deadline) && parsed == nil {
		for _, f := range decodeAX25Frames(fp.getSent()) {
			if f.Type == ax25.UI {
				parsed = f
				break
			}
		}
		time.Sleep(10 * time.Millisecond)
	}
	if parsed == nil {
		t.Fatal("frame with out-of-range port was dropped; it must be clamped to port 0 and transmitted")
	}
	if got := parsed.Src.String(); got != "KU0HN-2" {
		t.Errorf("src = %q, want KU0HN-2", got)
	}
}

// connectedSession registers KU0HN-10 on a fresh client, connects to N0CALL-2
// and completes the handshake, consuming the 'X' and 'C' replies.
func connectedSession(t *testing.T) (*engine.Engine, *bridge.Bridge, *fakePort, net.Listener, net.Conn) {
	t.Helper()
	eng := engine.New()
	go eng.Run()
	t.Cleanup(eng.Stop)
	fp := newFakePort(true)
	b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
		{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
	})
	ln, conn := dialServe(t, eng, b)
	t.Cleanup(func() { conn.Close(); ln.Close() })
	time.Sleep(20 * time.Millisecond)
	writeFrame(t, conn, 0, 'X', 0, "KU0HN-10", "", nil)
	readOneFrame(t, conn)
	writeFrame(t, conn, 0, 'C', 0, "KU0HN-10", "N0CALL-2", nil)
	sabm := waitForSABM(t, fp)
	ua := &ax25.Frame{Dst: sabm.Src, Src: sabm.Dst, Type: ax25.UA, PF: true}
	onLoop(t, eng, func() { b.OnKISSFrame(kiss.RXFrame{Port: 0, Data: ua.Bytes()}) })
	if c := readOneFrame(t, conn); c.Kind != 'C' {
		t.Fatalf("expected 'C', got %c", c.Kind)
	}
	return eng, b, fp, ln, conn
}

// The remote's DISC is reported with Dire Wolf's wording.
func TestRemoteDisconnectMessage(t *testing.T) {
	eng, b, _, _, conn := connectedSession(t)
	disc := &ax25.Frame{
		Dst: ax25.Address{Call: "KU0HN", SSID: 10}, Src: ax25.Address{Call: "N0CALL", SSID: 2},
		Type: ax25.DISC, PF: true, Command: true,
	}
	onLoop(t, eng, func() { b.OnKISSFrame(kiss.RXFrame{Port: 0, Data: disc.Bytes()}) })
	d := readOneFrame(t, conn)
	if d.Kind != 'd' || string(d.Data) != "*** DISCONNECTED From Station N0CALL-2\r" {
		t.Fatalf("got %c %q, want 'd' \"*** DISCONNECTED From Station N0CALL-2\\r\"", d.Kind, d.Data)
	}
}

// A connect to an unencodable callsign is refused with a reason, and nothing
// is transmitted.
func TestConnectInvalidCallsignRefused(t *testing.T) {
	for _, kind := range []byte{'C', 'c', 'v'} {
		eng := engine.New()
		go eng.Run()
		fp := newFakePort(true)
		b := makeBridgeWithFakePort(t, eng, []*fakePort{fp}, []config.Port{
			{Name: "Port 0", Type: "serial", Device: "/dev/null", OTABaudrate: 1200},
		})
		ln, conn := dialServe(t, eng, b)
		time.Sleep(20 * time.Millisecond)
		writeFrame(t, conn, 0, kind, 0, "KU0HN-10", "TOOLONGCALL", nil)
		d := readOneFrame(t, conn)
		if d.Kind != 'd' || !strings.Contains(string(d.Data), "invalid callsign") {
			t.Errorf("%c: reply %c %q, want 'd' naming the invalid callsign", kind, d.Kind, d.Data)
		}
		time.Sleep(20 * time.Millisecond)
		if n := len(fp.getSent()); n != 0 {
			t.Errorf("%c: %d frame(s) transmitted for an invalid callsign", kind, n)
		}
		conn.Close()
		ln.Close()
		eng.Stop()
	}
}

// 'K' ownership is decided by the addresses inside the raw frame, not by the
// (unrelated, client-chosen) AGWPE header callsigns: a second client must not
// inject frames into another client's session.
func TestRawFrameIntoForeignSessionRejected(t *testing.T) {
	eng, b, fp, ln, _ := connectedSession(t)
	other, err := net.DialTimeout("tcp", ln.Addr().String(), 2*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer other.Close()
	time.Sleep(20 * time.Millisecond)
	writeFrame(t, other, 0, 'X', 0, "N0BODY", "", nil)
	readOneFrame(t, other)
	before := len(fp.getSent())
	inject := &ax25.Frame{
		Dst: ax25.Address{Call: "N0CALL", SSID: 2}, Src: ax25.Address{Call: "KU0HN", SSID: 10},
		Type: ax25.I, PID: 0xF0, Info: []byte("spoof"), Command: true,
	}
	writeFrame(t, other, 0, 'K', 0, "N0BODY", "CQ", append([]byte{0}, inject.Bytes()...))
	time.Sleep(50 * time.Millisecond)
	onLoop(t, eng, func() {})
	_ = b
	if after := len(fp.getSent()); after != before {
		t.Fatalf("foreign client's raw frame into an owned session was transmitted")
	}
}
