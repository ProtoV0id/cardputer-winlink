// Package config loads, validates, and migrates tncd INI configuration files.
// It is drop-in compatible with the Python 1.x tncd.ini format.
package config

import (
	"fmt"
	"log"
	"sort"
	"strconv"
	"strings"

	"github.com/ben-kuhn/tncd/v2/internal/netutil"
	"github.com/ben-kuhn/tncd/v2/kiss"
	"gopkg.in/ini.v1"
)

// Server holds the [server] section settings.
type Server struct {
	ListenHost  string // default "127.0.0.1"
	ListenPort  int    // default 8000
	Callsign    string // default "AGWPE"
	MaxClients  int    // default 8
	IdleTimeout int    // seconds, default 300, <=0 disables
	// AllowedSubnets restricts AGWPE client source IPs. Empty = allow all.
	AllowedSubnets netutil.Allowlist
}

// AX25 holds the [ax25] section settings.
type AX25 struct {
	MaxWindow int // default 3, clamped 1..7
	N2Retry   int // default 10
	T3Timeout int // seconds, default 180, <=0 disables
	// Frack is the connection-setup retransmit interval in seconds: how long to
	// wait for a UA after sending SABM/SABME/DISC before resending. Named for
	// the FRACK parameter in TNC firmware. Default 3 (Dire Wolf's default; a
	// KPC-3+ uses 4, a TM-D710A 3). Scaled by 2m+1 for m digipeater hops.
	// Distinct from the data-phase T1, which is derived from ota_baudrate.
	Frack int
}

// KISSTCP holds the [kisstcp] section: a KISS-over-TCP passthrough listener.
type KISSTCP struct {
	Enabled     bool   // default false
	ListenHost  string // default "127.0.0.1"
	ListenPort  int    // default 8001
	MaxClients  int    // default 16
	IdleTimeout int    // seconds, default 300, <=0 disables
	// AllowedSubnets restricts client source IPs. Empty = allow all.
	AllowedSubnets netutil.Allowlist
}

// APIConfig holds the [api] section: a read-only HTTP monitoring API.
type APIConfig struct {
	Enabled    bool   // default false
	ListenHost string // default "127.0.0.1"
	ListenPort int    // default 8002
	MaxClients int    // default 16
	ServeUI    bool   // default true — serve the embedded web monitor at /
	// AllowedSubnets restricts client source IPs. Empty = allow all.
	AllowedSubnets netutil.Allowlist
	// AllowedHosts lists extra Host-header hostnames the API answers to
	// (e.g. a tunnel or LAN name). IP literals and "localhost" are always
	// accepted; any other name is refused, which blocks DNS rebinding.
	AllowedHosts []string
}

// Port holds one [client.N] section's settings plus the associated [kiss.N] params.
type Port struct {
	Name string // default "Port N"
	Type string // "serial" | "tcp" | "bluetooth" (classic SPP) | "ble" (BLE KISS)

	// serial
	Device         string
	SerialBaudrate int     // default 9600; legacy key "baudrate" honored
	Parity         string  // default "N"
	StopBits       float64 // default 1
	RTSCTS         bool    // default false

	// tcp
	Host    string
	TCPPort int

	// bluetooth
	BDAddr            string
	Channel           string  // empty = SDP auto-detect
	Reconnect         bool    // default true
	ReconnectDelay    float64 // default 5
	ReconnectMaxDelay float64 // default 60

	// common
	OTABaudrate    int     // default 1200
	Paclen         int     // per-port N1 (max I-frame info); 0 = 256
	InitString     string  // raw, with \r \n escapes unresolved
	InitDelay      float64 // default 1.0
	SendKISSExit   bool    // default true
	HostExitString string
	ExitDelay      float64 // default 1.0

	AX25Version int  // 20 or 22; default 22
	SREJ        bool // v2.2 selective reject; default true, effective only on mod-128 links

	// TXPacing bounds how far ahead of the air tncd hands frames to the TNC,
	// using ota_baudrate as the channel rate (see kiss/pacing.go). Default
	// true. Set false to hand frames over as fast as the transport accepts
	// them, which is what tncd did before pacing existed -- useful for
	// isolating pacing from a problem under test, or if ota_baudrate is
	// deliberately wrong.
	TXPacing bool

	// RXWedgeTimeout is the read-side watchdog: if a connection has unacked TX
	// outstanding and NO frame of any kind arrives on this port for this many
	// seconds, the link is treated as a wedged Bluetooth SPP RX and auto-relinked.
	// Seconds; 0 disables. Default 20 for bluetooth, 0 for serial/tcp.
	RXWedgeTimeout int

	// VFOChannelMin is the lowest channel-record id rig control will
	// overwrite when tuning a Benshi radio. These radios have no scratch
	// frequency register -- a VFO is an index into the channel table -- so
	// QSY rewrites the record the active VFO points at, and this bounds
	// which records that is allowed to be. Verified on a BTech UV-PRO,
	// whose VFOs live at 251 and 252 above a memory bank starting at 0.
	// Other Benshi variants are not confirmed to number theirs the same
	// way, so it is configurable: a radio that refuses to tune says which
	// channel it is on, and setting this to that id allows it.
	// Default 251. Only consulted for rig control.
	VFOChannelMin int

	KISS kiss.Params // from [kiss.N]; nil fields = don't send
}

// RigCtl holds one [rigctl.N] section: a hamlib Net rigctl listener for port N.
//
// One listener per port because hamlib's Net rigctl protocol has no way to
// select among several rigs on one socket.
type RigCtl struct {
	Enabled    bool   // default false; the module is opt-in
	ListenHost string // default "127.0.0.1"
	ListenPort int    // default 4532 + N
	// AllowedSubnets restricts rigctl client source IPs. Empty = allow all.
	AllowedSubnets netutil.Allowlist
	AllowPTT       bool // default false; see PTTTimeout
	// PTTTimeout is the maximum time tncd will leave the transmitter keyed
	// before force-releasing it, in seconds. Default 30. A remote key whose
	// un-key path can be swallowed by a wedged Bluetooth link is a stuck
	// transmitter, so this is not optional when AllowPTT is set.
	PTTTimeout int
}

// Config is the parsed configuration.
type Config struct {
	Server  Server
	AX25    AX25
	KISSTCP KISSTCP
	API     APIConfig
	Ports   []Port
	// RigCtl holds one entry per configured port (RigCtl[i] is [rigctl.i],
	// defaulted even when the section is absent), matching Ports by index.
	RigCtl []RigCtl
}

// knownServerKeys are the recognized keys in [server].
var knownServerKeys = []string{
	"listen_host", "listen_port", "callsign", "max_clients", "idle_timeout",
	"allowed_subnets",
}

// knownAX25Keys are the recognized keys in [ax25].
var knownAX25Keys = []string{
	"max_window", "n2_retry", "t3_timeout", "frack",
}

// knownRigCtlKeys are the recognized keys in [rigctl.N].
var knownRigCtlKeys = []string{
	"enabled", "listen_host", "listen_port", "allowed_subnets",
	"allow_ptt", "ptt_timeout",
}

// knownKISSTCPKeys are the recognized keys in [kisstcp].
var knownKISSTCPKeys = []string{
	"enabled", "listen_host", "listen_port", "max_clients", "idle_timeout",
	"allowed_subnets",
}

// knownAPIKeys are the recognized keys in [api].
var knownAPIKeys = []string{
	"enabled", "listen_host", "listen_port", "max_clients", "serve_ui",
	"allowed_subnets", "allowed_hosts",
}

// knownClientKeys are the recognized keys in [client.N].
var knownClientKeys = []string{
	"name", "type",
	"device", "serial_baudrate", "baudrate", "parity", "stopbits", "rtscts",
	"host", "port",
	"bdaddr", "channel", "reconnect", "reconnect_delay", "reconnect_max_delay",
	"ota_baudrate", "paclen", "init_string", "init_delay", "send_kiss_exit",
	"host_exit_string", "exit_delay",
	"ax25_version", "srej", "rx_wedge_timeout", "tx_pacing",
}

// knownKISSKeys are the recognized keys in [kiss.N].
var knownKISSKeys = []string{
	"tx_delay", "persistence", "slot_time", "tx_tail", "full_duplex",
}

// maxPorts caps the number of [client.N] sections. Beyond 16 the KISS-TCP /
// raw-'K' port nibble (byte(port)<<4) wraps, and beyond 255 the AGWPE port
// byte wraps. Realistic stations use <= 4; a config declaring more than 16 is
// almost certainly a mistake worth surfacing at load rather than a wrap-around
// bug on the wire.
const maxPorts = 16

// levenshtein computes the edit distance between two strings.
func levenshtein(a, b string) int {
	la, lb := len(a), len(b)
	if la == 0 {
		return lb
	}
	if lb == 0 {
		return la
	}
	// dp[j] = distance from a[:i] to b[:j]
	dp := make([]int, lb+1)
	for j := range dp {
		dp[j] = j
	}
	for i := 1; i <= la; i++ {
		prev := dp[0]
		dp[0] = i
		for j := 1; j <= lb; j++ {
			tmp := dp[j]
			if a[i-1] == b[j-1] {
				dp[j] = prev
			} else {
				min3 := prev
				if dp[j-1]+1 < min3 {
					min3 = dp[j-1] + 1
				}
				if dp[j]+1 < min3 {
					min3 = dp[j] + 1
				}
				dp[j] = min3
			}
			prev = tmp
		}
	}
	return dp[lb]
}

// closestKey returns the closest known key within Levenshtein distance <= 2,
// or "" if none found.
func closestKey(key string, known []string) string {
	best := ""
	bestDist := 3 // only accept <= 2
	for _, k := range known {
		d := levenshtein(key, k)
		if d < bestDist {
			bestDist = d
			best = k
		}
	}
	return best
}

// warnUnknownKeys logs a warning for any key in a section that is not in the known list.
func warnUnknownKeys(section *ini.Section, known []string) {
	for _, key := range section.Keys() {
		name := key.Name()
		found := false
		for _, k := range known {
			if k == name {
				found = true
				break
			}
		}
		if !found {
			closest := closestKey(name, known)
			if closest != "" {
				log.Printf("warning: [%s] unknown key %q (did you mean %q?)", section.Name(), name, closest)
			} else {
				log.Printf("warning: [%s] unknown key %q", section.Name(), name)
			}
		}
	}
}

// getInt returns an int from a section key with a fallback default.
// An unparseable value falls back to the default and logs a warning, so a
// typo like `listen_port = 800o` does not silently change behaviour.
func getInt(s *ini.Section, key string, def int) int {
	if s.HasKey(key) {
		v, err := s.Key(key).Int()
		if err == nil {
			return v
		}
		log.Printf("warning: [%s] %s = %q is not a valid integer; using %d",
			s.Name(), key, s.Key(key).String(), def)
	}
	return def
}

// getFloat returns a float64 from a section key with a fallback default.
// An unparseable value falls back to the default and logs a warning.
func getFloat(s *ini.Section, key string, def float64) float64 {
	if s.HasKey(key) {
		v, err := s.Key(key).Float64()
		if err == nil {
			return v
		}
		log.Printf("warning: [%s] %s = %q is not a valid number; using %v",
			s.Name(), key, s.Key(key).String(), def)
	}
	return def
}

// getBool returns a bool from a section key with a fallback default.
func getBool(s *ini.Section, key string, def bool) bool {
	if s.HasKey(key) {
		v, err := s.Key(key).Bool()
		if err == nil {
			return v
		}
		// handle "true"/"false" already handled by ini, but also handle 0/1
		raw := s.Key(key).String()
		if raw == "0" {
			return false
		}
		if raw == "1" {
			return true
		}
	}
	return def
}

// getString returns the string value of a key, or the default if absent.
func getString(s *ini.Section, key string, def string) string {
	if s.HasKey(key) {
		return s.Key(key).String()
	}
	return def
}

// getList returns a comma-separated key as trimmed, non-empty entries.
func getList(s *ini.Section, key string) []string {
	var out []string
	for _, v := range strings.Split(getString(s, key, ""), ",") {
		if v = strings.TrimSpace(v); v != "" {
			out = append(out, v)
		}
	}
	return out
}

// parseAllowlistKey parses a comma-separated CIDR allowlist key. Absent or
// empty yields an empty (allow-all) Allowlist; an invalid entry is a
// config-load error.
func parseAllowlistKey(s *ini.Section, key string) (netutil.Allowlist, error) {
	if !s.HasKey(key) {
		return netutil.Allowlist{}, nil
	}
	return netutil.ParseAllowlist(s.Key(key).String())
}

// getIntPtr returns a *int from a section key, or nil if absent.
// An unparseable value logs a warning and returns nil (field left unset).
func getIntPtr(s *ini.Section, key string) *int {
	if s.HasKey(key) {
		v, err := s.Key(key).Int()
		if err == nil {
			return &v
		}
		log.Printf("warning: [%s] %s = %q is not a valid integer; leaving unset",
			s.Name(), key, s.Key(key).String())
	}
	return nil
}

// Load reads and parses the INI file at path. If path is empty, returns
// defaults plus one serial port (client.0, /dev/ttyUSB0).
// defaultVFOChannelMin is the default lowest channel-record id rig control
// will overwrite. 251 is where a BTech UV-PRO's two VFO scratch records sit
// (251 and 252), above a memory bank that starts at 0. See Port.VFOChannelMin.
const defaultVFOChannelMin = 251

func Load(path string) (*Config, error) {
	// Configure ini to be lenient (allows inline comments, etc.)
	opts := ini.LoadOptions{
		IgnoreInlineComment:         true,
		UnescapeValueDoubleQuotes:   false,
		UnescapeValueCommentSymbols: false,
		InsensitiveKeys:             true,
	}

	var f *ini.File
	var err error

	if path == "" {
		// No config file: use defaults only.
		f = ini.Empty()
	} else {
		f, err = ini.LoadSources(opts, path)
		if err != nil {
			return nil, fmt.Errorf("load %s: %w", path, err)
		}
	}

	// --- Migrate bare [client] / [kiss] sections to numbered form ---
	if f.HasSection("client") {
		// Only migrate if there are no client.N sections
		hasNumbered := false
		for _, s := range f.Sections() {
			if len(s.Name()) > 7 && s.Name()[:7] == "client." {
				hasNumbered = true
				break
			}
		}
		if !hasNumbered {
			log.Printf("warning: [client] section is deprecated; rename to [client.0]")
			// Create client.0 and copy keys
			newSec, _ := f.NewSection("client.0")
			for _, k := range f.Section("client").Keys() {
				newSec.NewKey(k.Name(), k.Value())
			}
			f.DeleteSection("client")
		}
	}

	if f.HasSection("kiss") {
		// Only migrate if there are no kiss.N sections
		hasNumbered := false
		for _, s := range f.Sections() {
			if len(s.Name()) > 5 && s.Name()[:5] == "kiss." {
				hasNumbered = true
				break
			}
		}
		if !hasNumbered {
			log.Printf("warning: [kiss] section is deprecated; rename to [kiss.0]")
			newSec, _ := f.NewSection("kiss.0")
			for _, k := range f.Section("kiss").Keys() {
				newSec.NewKey(k.Name(), k.Value())
			}
			f.DeleteSection("kiss")
		}
	}

	// --- If no client.N sections, create a default client.0 ---
	hasClientSection := false
	for _, s := range f.Sections() {
		name := s.Name()
		if len(name) > 7 && name[:7] == "client." {
			hasClientSection = true
			break
		}
	}
	if !hasClientSection && path == "" {
		// CLI/default mode: add client.0 with serial defaults
		newSec, _ := f.NewSection("client.0")
		newSec.NewKey("type", "serial")
		newSec.NewKey("device", "/dev/ttyUSB0")
		newSec.NewKey("serial_baudrate", "9600")
		newSec.NewKey("ota_baudrate", "1200")
	}

	// --- Parse [server] ---
	serverSec := f.Section("server")
	warnUnknownKeys(serverSec, knownServerKeys)
	cfg := &Config{}
	serverAllow, err := parseAllowlistKey(serverSec, "allowed_subnets")
	if err != nil {
		return nil, fmt.Errorf("[server] %w", err)
	}
	cfg.Server = Server{
		ListenHost:     getString(serverSec, "listen_host", "127.0.0.1"),
		ListenPort:     getInt(serverSec, "listen_port", 8000),
		Callsign:       getString(serverSec, "callsign", "AGWPE"),
		MaxClients:     getInt(serverSec, "max_clients", 8),
		IdleTimeout:    getInt(serverSec, "idle_timeout", 300),
		AllowedSubnets: serverAllow,
	}

	// --- Parse [ax25] ---
	ax25Sec := f.Section("ax25")
	warnUnknownKeys(ax25Sec, knownAX25Keys)
	maxWindow := getInt(ax25Sec, "max_window", 3)
	if maxWindow < 1 {
		maxWindow = 1
	}
	if maxWindow > 7 {
		maxWindow = 7
	}
	cfg.AX25 = AX25{
		MaxWindow: maxWindow,
		N2Retry:   getInt(ax25Sec, "n2_retry", 10),
		T3Timeout: getInt(ax25Sec, "t3_timeout", 180),
		Frack:     getInt(ax25Sec, "frack", 3),
	}
	if cfg.AX25.Frack < 1 {
		// A sub-second setup timer would retransmit SABMs faster than a
		// half-duplex radio can key up and get a UA back, burning N2 on frames
		// that never had time to be answered.
		log.Printf("warning: [ax25] frack = %d is invalid; using 3", cfg.AX25.Frack)
		cfg.AX25.Frack = 3
	}
	if cfg.AX25.N2Retry < 1 {
		// n2_retry <= 0 makes a connect give up after the first T1 (one SABM,
		// ~3s) with no warning. Clamp so retries actually happen.
		log.Printf("warning: [ax25] n2_retry = %d is invalid; using 1", cfg.AX25.N2Retry)
		cfg.AX25.N2Retry = 1
	}

	// --- Parse [kisstcp] ---
	kisstcpSec := f.Section("kisstcp")
	warnUnknownKeys(kisstcpSec, knownKISSTCPKeys)
	kisstcpAllow, err := parseAllowlistKey(kisstcpSec, "allowed_subnets")
	if err != nil {
		return nil, fmt.Errorf("[kisstcp] %w", err)
	}
	cfg.KISSTCP = KISSTCP{
		Enabled:        getBool(kisstcpSec, "enabled", false),
		ListenHost:     getString(kisstcpSec, "listen_host", "127.0.0.1"),
		ListenPort:     getInt(kisstcpSec, "listen_port", 8001),
		MaxClients:     getInt(kisstcpSec, "max_clients", 16),
		IdleTimeout:    getInt(kisstcpSec, "idle_timeout", 300),
		AllowedSubnets: kisstcpAllow,
	}

	// --- Parse [api] ---
	apiSec := f.Section("api")
	warnUnknownKeys(apiSec, knownAPIKeys)
	apiAllow, err := parseAllowlistKey(apiSec, "allowed_subnets")
	if err != nil {
		return nil, fmt.Errorf("[api] %w", err)
	}
	cfg.API = APIConfig{
		Enabled:        getBool(apiSec, "enabled", false),
		ListenHost:     getString(apiSec, "listen_host", "127.0.0.1"),
		ListenPort:     getInt(apiSec, "listen_port", 8002),
		MaxClients:     getInt(apiSec, "max_clients", 16),
		ServeUI:        getBool(apiSec, "serve_ui", true),
		AllowedSubnets: apiAllow,
		AllowedHosts:   getList(apiSec, "allowed_hosts"),
	}

	// --- Collect client.N and kiss.N sections ---
	type portEntry struct {
		idx  int
		name string
	}
	var portEntries []portEntry
	kissMap := map[int]*ini.Section{}

	for _, s := range f.Sections() {
		name := s.Name()
		if len(name) > 7 && name[:7] == "client." {
			idxStr := name[7:]
			idx, err := strconv.Atoi(idxStr)
			if err == nil {
				portEntries = append(portEntries, portEntry{idx, name})
			}
		} else if len(name) > 5 && name[:5] == "kiss." {
			idxStr := name[5:]
			idx, err := strconv.Atoi(idxStr)
			if err == nil {
				kissMap[idx] = s
			}
		}
	}

	// Sort by index
	sort.Slice(portEntries, func(i, j int) bool {
		return portEntries[i].idx < portEntries[j].idx
	})

	// --- Validate contiguous numbering ---
	if len(portEntries) == 0 {
		return nil, fmt.Errorf("no [client.N] sections found; define at least [client.0]")
	}
	if len(portEntries) > maxPorts {
		return nil, fmt.Errorf("too many ports: %d (max %d)", len(portEntries), maxPorts)
	}
	for i, pe := range portEntries {
		if pe.idx != i {
			actual := make([]int, len(portEntries))
			for j, e := range portEntries {
				actual[j] = e.idx
			}
			return nil, fmt.Errorf("port numbering must be contiguous starting from 0 (not contiguous): found %v", actual)
		}
	}

	// --- Parse each port ---
	cfg.Ports = make([]Port, len(portEntries))
	for i, pe := range portEntries {
		s := f.Section(pe.name)
		warnUnknownKeys(s, knownClientKeys)

		portType := getString(s, "type", "")
		if portType == "" {
			return nil, fmt.Errorf("[%s] missing required 'type' field", pe.name)
		}
		validTypes := map[string]bool{"serial": true, "tcp": true, "bluetooth": true, "ble": true}
		if !validTypes[portType] {
			return nil, fmt.Errorf("[%s] invalid type %q; must be one of: ble, bluetooth, serial, tcp", pe.name, portType)
		}

		// Validate required fields per type
		switch portType {
		case "serial":
			if !s.HasKey("device") || s.Key("device").String() == "" {
				return nil, fmt.Errorf("[%s] type=serial is missing required field: device", pe.name)
			}
		case "tcp":
			missingFields := []string{}
			if !s.HasKey("host") || s.Key("host").String() == "" {
				missingFields = append(missingFields, "host")
			}
			if !s.HasKey("port") || s.Key("port").String() == "" {
				missingFields = append(missingFields, "port")
			}
			if len(missingFields) > 0 {
				return nil, fmt.Errorf("[%s] type=tcp is missing required field(s): %v", pe.name, missingFields)
			}
		case "bluetooth", "ble":
			if !s.HasKey("bdaddr") || s.Key("bdaddr").String() == "" {
				return nil, fmt.Errorf("[%s] type=%s is missing required field: bdaddr", pe.name, portType)
			}
		}

		// serial_baudrate with legacy fallback to "baudrate"
		serialBaudrate := 9600
		if s.HasKey("serial_baudrate") {
			if v, err := s.Key("serial_baudrate").Int(); err == nil {
				serialBaudrate = v
			}
		} else if s.HasKey("baudrate") {
			if v, err := s.Key("baudrate").Int(); err == nil {
				serialBaudrate = v
			}
		}

		ax25Version := 22
		if s.HasKey("ax25_version") {
			switch s.Key("ax25_version").String() {
			case "2.0":
				ax25Version = 20
			case "2.2":
				ax25Version = 22
			default:
				return nil, fmt.Errorf("[%s] invalid ax25_version %q; must be 2.0 or 2.2",
					pe.name, s.Key("ax25_version").String())
			}
		}

		// Read-side wedge watchdog defaults on for Bluetooth (the SPP RX path
		// can half-wedge under sustained load), off for serial/tcp.
		rxWedgeDefault := 0
		if portType == "bluetooth" {
			rxWedgeDefault = 20
		}

		port := Port{
			Name:              getString(s, "name", fmt.Sprintf("Port %d", i)),
			Type:              portType,
			Device:            getString(s, "device", ""),
			SerialBaudrate:    serialBaudrate,
			Parity:            getString(s, "parity", "N"),
			StopBits:          getFloat(s, "stopbits", 1),
			RTSCTS:            getBool(s, "rtscts", false),
			Host:              getString(s, "host", ""),
			TCPPort:           getInt(s, "port", 0),
			BDAddr:            getString(s, "bdaddr", ""),
			Channel:           getString(s, "channel", ""),
			Reconnect:         getBool(s, "reconnect", true),
			ReconnectDelay:    getFloat(s, "reconnect_delay", 5),
			ReconnectMaxDelay: getFloat(s, "reconnect_max_delay", 60),
			OTABaudrate:       getInt(s, "ota_baudrate", 1200),
			Paclen:            getInt(s, "paclen", 0),
			InitString:        getString(s, "init_string", ""),
			InitDelay:         getFloat(s, "init_delay", 1.0),
			SendKISSExit:      getBool(s, "send_kiss_exit", true),
			HostExitString:    getString(s, "host_exit_string", ""),
			ExitDelay:         getFloat(s, "exit_delay", 1.0),
			AX25Version:       ax25Version,
			SREJ:              getBool(s, "srej", true),
			TXPacing:          getBool(s, "tx_pacing", true),
			RXWedgeTimeout:    getInt(s, "rx_wedge_timeout", rxWedgeDefault),
			VFOChannelMin:     getInt(s, "vfo_channel_min", defaultVFOChannelMin),
		}

		// Serial-only params validated at load: a typo in parity/stopbits must
		// surface as a `tncd check` error, not as an endless reconnect loop once
		// the serial port fails to Open.
		if portType == "serial" {
			if err := validateSerialParams(pe.name, &port); err != nil {
				return nil, err
			}
		}

		// Parse corresponding [kiss.N] section if present
		if ks, ok := kissMap[i]; ok {
			warnUnknownKeys(ks, knownKISSKeys)
			port.KISS = kiss.Params{
				TXDelay:     getIntPtr(ks, "tx_delay"),
				Persistence: getIntPtr(ks, "persistence"),
				SlotTime:    getIntPtr(ks, "slot_time"),
				TXTail:      getIntPtr(ks, "tx_tail"),
				FullDuplex:  getIntPtr(ks, "full_duplex"),
			}
			if err := validateKISSParams(fmt.Sprintf("kiss.%d", i), port.KISS); err != nil {
				return nil, err
			}
		}

		cfg.Ports[i] = port
	}

	// --- Parse [rigctl.N], one per configured port (section optional) ---
	cfg.RigCtl = make([]RigCtl, len(portEntries))
	for i := range portEntries {
		secName := fmt.Sprintf("rigctl.%d", i)
		s := f.Section(secName) // ini creates an empty section on demand
		warnUnknownKeys(s, knownRigCtlKeys)

		rigctlAllow, err := parseAllowlistKey(s, "allowed_subnets")
		if err != nil {
			return nil, fmt.Errorf("[%s] %w", secName, err)
		}

		pttTimeout := getInt(s, "ptt_timeout", 30)
		if pttTimeout <= 0 {
			// A zero or negative timeout would defeat the stuck-transmitter
			// guard (tncd could leave the rig keyed indefinitely), so treat
			// it the same as n2_retry <= 0: clamp and warn, don't silently
			// disable the safety bound.
			log.Printf("warning: [%s] ptt_timeout = %d is invalid; using 30", secName, pttTimeout)
			pttTimeout = 30
		}

		cfg.RigCtl[i] = RigCtl{
			Enabled:        getBool(s, "enabled", false),
			ListenHost:     getString(s, "listen_host", "127.0.0.1"),
			ListenPort:     getInt(s, "listen_port", 4532+i),
			AllowedSubnets: rigctlAllow,
			AllowPTT:       getBool(s, "allow_ptt", false),
			PTTTimeout:     pttTimeout,
		}
	}

	warnDuplicatePorts(cfg.Ports)

	return cfg, nil
}

// warnDuplicatePorts flags two ports that share one physical TNC — the same
// serial device or Bluetooth address — which would fight over the same link
// (two decoders splitting one byte stream, or two SPP connections to one
// radio). A warning beats silent misconfiguration; a typo'd address is
// indistinguishable from a deliberate (if usually wrong) shared-TNC setup.
func warnDuplicatePorts(ports []Port) {
	seenDevice := map[string]int{}
	seenAddr := map[string]int{}
	for i, p := range ports {
		if p.Device != "" {
			if first, dup := seenDevice[p.Device]; dup {
				log.Printf("warning: [client.%d] and [client.%d] share device %q — they will fight over the same TNC",
					first, i, p.Device)
			} else {
				seenDevice[p.Device] = i
			}
		}
		if p.BDAddr != "" {
			if first, dup := seenAddr[p.BDAddr]; dup {
				log.Printf("warning: [client.%d] and [client.%d] share Bluetooth address %q — they will fight over the same TNC",
					first, i, p.BDAddr)
			} else {
				seenAddr[p.BDAddr] = i
			}
		}
	}
}

// validateKISSParams range-checks [kiss.N] values at load: each is one byte
// on the wire, so an out-of-range value would otherwise wrap silently.
func validateKISSParams(secName string, k kiss.Params) error {
	for _, prm := range []struct {
		key string
		val *int
		max int
	}{
		{"tx_delay", k.TXDelay, 255},
		{"persistence", k.Persistence, 255},
		{"slot_time", k.SlotTime, 255},
		{"tx_tail", k.TXTail, 255},
		{"full_duplex", k.FullDuplex, 1},
	} {
		if prm.val != nil && (*prm.val < 0 || *prm.val > prm.max) {
			return fmt.Errorf("[%s] %s = %d is out of range (0-%d)", secName, prm.key, *prm.val, prm.max)
		}
	}
	return nil
}

// validateSerialParams checks parity/stopbits at load time so a typo produces
// a `tncd check` error instead of an endless reconnect loop when the serial
// port fails to Open. Mirrors kiss/parseParity and kiss/parseStopBits.
func validateSerialParams(secName string, port *Port) error {
	switch strings.ToUpper(port.Parity) {
	case "", "N", "E", "O":
	default:
		return fmt.Errorf("[%s] invalid parity %q (use N, E, or O)", secName, port.Parity)
	}
	switch port.StopBits {
	case 0, 1, 1.5, 2:
	default:
		return fmt.Errorf("[%s] invalid stopbits %v (use 1, 1.5, or 2)", secName, port.StopBits)
	}
	return nil
}

// Validate checks the config for logical errors and returns an error naming
// the section and key if any required fields are missing or invalid.
// Load already performs all validation; this method is provided for
// post-load re-validation after programmatic modification.
func (c *Config) Validate() error {
	validTypes := map[string]bool{"serial": true, "tcp": true, "bluetooth": true, "ble": true}
	for i, p := range c.Ports {
		secName := fmt.Sprintf("client.%d", i)
		if p.Type == "" {
			return fmt.Errorf("[%s] missing required 'type' field", secName)
		}
		if !validTypes[p.Type] {
			return fmt.Errorf("[%s] invalid type %q; must be one of: ble, bluetooth, serial, tcp", secName, p.Type)
		}
		switch p.Type {
		case "serial":
			if p.Device == "" {
				return fmt.Errorf("[%s] type=serial is missing required field: device", secName)
			}
		case "tcp":
			if p.Host == "" {
				return fmt.Errorf("[%s] type=tcp is missing required field: host", secName)
			}
			if p.TCPPort == 0 {
				return fmt.Errorf("[%s] type=tcp is missing required field: port", secName)
			}
		case "bluetooth", "ble":
			if p.BDAddr == "" {
				return fmt.Errorf("[%s] type=%s is missing required field: bdaddr", secName, p.Type)
			}
		}
	}
	return nil
}
