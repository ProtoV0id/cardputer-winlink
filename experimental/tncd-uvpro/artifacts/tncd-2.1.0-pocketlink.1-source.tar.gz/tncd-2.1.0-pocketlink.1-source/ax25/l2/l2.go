package l2

import (
	"fmt"
	"strings"
	"time"

	"github.com/ben-kuhn/tncd/v2/ax25"
	"github.com/ben-kuhn/tncd/v2/internal/engine"
)

const maxConnections = 64

// ax25Overhead is the overhead per frame for T1 calculation.
// tncd.py:1073: max_frame_bytes = 256 + AX25_OVERHEAD
// AX25_OVERHEAD = 20 (from tncd.py constants)
const ax25Overhead = 20

// PortParams holds the T1/T2/T3 timing and window parameters for one port.
// Derived from ota_baudrate via DeriveParams (tncd.py:1068-1087).
type PortParams struct {
	MaxWindow   int
	Paclen      int // per-port max I-frame info (N1); <=0 means maxIFrameInfo
	// T1Floor is the shortest T1 the RTT estimator may settle on: the time it
	// physically takes to put the outstanding window on the air and get an
	// answer back. Retransmitting sooner than this cannot be correct -- the
	// data has not finished being transmitted yet.
	T1Floor time.Duration
	N2Retry     int
	T1          time.Duration // data-phase retransmit: max(3s, 2*(window*frameTime + 1s))
	T1Setup     time.Duration // connection-phase retransmit base (FRACK); 0 means defaultT1Setup
	T2          time.Duration // max(100ms, 1.2*frameTime)
	T3          time.Duration // 0 disables
	AX25Version int           // 20 (mod-8 only) or 22 (attempt SABME/mod-128); default 20
	SREJ        bool          // v2.2 selective reject enabled for this port (default set by bridge)
}

// defaultT1Setup is the base connection-phase retransmit interval: how long to
// wait for a UA after a SABM/SABME/DISC before resending.
//
// This is deliberately NOT derived from the data-phase T1. T1 is sized as
// 2*(window*maxFrameTime + turnaround) -- the time to push a full window of
// 256-byte I-frames and get an ack back -- which at 1200 baud is 13s. But a
// connection handshake exchanges a ~17-byte command and a ~17-byte UA, about
// 0.25s of air time at 1200 baud, so the data-phase timer sized the setup
// retry for traffic that by definition is not flowing yet: a failed connect
// took 130s at the default N2 of 10, and retries were sparse enough to miss a
// timing-marginal radio's acceptance window entirely.
//
// 3s matches Dire Wolf's AX25_T1V_FRACK_DEFAULT, whose comment cites the real
// TNCs it was chosen against ("KPC-3+ has 4. TM-D710A has 3").
const defaultT1Setup = 3 * time.Second

// setupT1 returns the connection-phase retransmit interval for a path with the
// given number of digipeater hops. Each hop has to relay the command outbound
// and the reply back, so the wait scales by 2m+1 -- Dire Wolf's INIT_T1V_SRT
// (ax25_link.c: frack * (2 * (num_addr - 2) + 1)). tncd previously applied no
// digipeater scaling at all, giving a 2-hop path the same patience as a direct
// one.
func setupT1(base time.Duration, digis int) time.Duration {
	if base <= 0 {
		base = defaultT1Setup
	}
	if digis < 0 {
		digis = 0
	}
	return base * time.Duration(2*digis+1)
}

// DeriveParams computes PortParams from the on-air baud rate and config.
// Mirrors tncd.py:1068-1087 for the data-phase timers; the connection-phase
// timer (T1Setup) is a deliberate divergence, see defaultT1Setup.
func DeriveParams(otaBaud, maxWindow, n2Retry, t3Seconds int, paclen ...int) PortParams {
	if otaBaud <= 0 {
		otaBaud = 1200
	}
	maxInfo := maxIFrameInfo
	if len(paclen) > 0 && paclen[0] > 0 {
		maxInfo = paclen[0]
	}
	maxFrameBytes := maxInfo + ax25Overhead
	frameTime := float64(maxFrameBytes*8) / float64(otaBaud) // seconds
	turnaround := 1.0
	t1Sec := 3.0
	if v := 2.0 * (float64(maxWindow)*frameTime + turnaround); v > t1Sec {
		t1Sec = v
	}
	// The estimator must never go below the time to transmit a full window plus
	// one turnaround. A flat floor ignores the link speed: 3s is sane at 9600
	// baud and far too short at 1200, where a 3-frame window of 254-byte
	// I-frames needs ~6s of air time on its own.
	t1FloorSec := 3.0
	if v := float64(maxWindow)*frameTime + turnaround; v > t1FloorSec {
		t1FloorSec = v
	}

	t2Sec := 0.1
	const t2Multiplier = 1.2
	if v := t2Multiplier * frameTime; v > t2Sec {
		t2Sec = v
	}
	return PortParams{
		MaxWindow: maxWindow,
		Paclen:    maxInfo,
		N2Retry:   n2Retry,
		T1:        time.Duration(t1Sec * float64(time.Second)),
		T1Floor:   time.Duration(t1FloorSec * float64(time.Second)),
		T1Setup:   defaultT1Setup,
		T2:        time.Duration(t2Sec * float64(time.Second)),
		T3:        time.Duration(t3Seconds) * time.Second,
	}
}

// FailReason distinguishes why a connection attempt failed.
// The bridge (notifyConnectFailed) logs the cause and picks the client message.
type FailReason int

const (
	// FailTimeout means SABM was sent N2 times with no UA response.
	// Bridge logs a timeout and tells the client "connect ... timed out".
	// (tncd.py:1519 sent the misleading "*** BUSY From {remote}"; the Go port
	// deliberately diverges for clarity.)
	FailTimeout FailReason = iota
	// FailDM means a DM frame was received while in Connecting state.
	// Bridge tells the client "connect ... refused (DM)" (was tncd.py:1953).
	FailDM
)

// Hooks are the callbacks l2 fires when state changes. All hooks are called
// synchronously on the engine loop (or the caller's goroutine in tests).
type Hooks struct {
	SendAX25      func(port int, f *ax25.Frame)         // → KISS TX
	Connected     func(c *Conn, incoming bool)          // → AGWPE 'C'
	ConnectFailed func(c *Conn, reason FailReason)      // SABM gave up → 'd'
	Data          func(c *Conn, pid uint8, data []byte) // → AGWPE 'D'
	Disconnected  func(c *Conn)                         // → AGWPE 'd'
	// Defer posts fn so that any frames already queued on the event loop are
	// processed before fn runs — mirrors asyncio loop.call_soon.
	// Bridge wires this to engine.Do. When nil, fn is called synchronously
	// (useful in tests that want predictable ordering without a real loop).
	Defer func(fn func())
	// PortSessions reports how many connections a port holds, called whenever
	// that count changes -- including on a connection created for an outgoing
	// SABM that never completes.
	//
	// Bridge wires this to rig control's session settings, which is why the
	// hook fires on CREATION rather than on Connected: the radio needs to be
	// out of dual watch and on the right frequency BEFORE the handshake, not
	// after the UA. A connection that gives up having never connected still
	// has to release what it took.
	PortSessions func(port int, n int)
	// IsLocal reports whether call is one of our registered callsigns on port.
	// Bridge wires this to the AGWPE clients' RegisteredCalls sets.
	// When nil, the permissive default (always true) is used so that all
	// existing tests pass unchanged without setting this hook.
	IsLocal func(port int, call string) bool
}

// connKey is the map key for the connection table.
type connKey struct {
	port          int
	local, remote string // always uppercase
}

func makeKey(port int, local, remote string) connKey {
	return connKey{
		port:   port,
		local:  strings.ToUpper(strings.TrimSpace(local)),
		remote: strings.ToUpper(strings.TrimSpace(remote)),
	}
}

// Table is the AX.25 connection table. Methods must be called on the engine
// loop (they are not concurrency-safe themselves).
type Table struct {
	clock     engine.Clock
	hooks     Hooks
	params    []PortParams
	conns     map[connKey]*Conn
	portCount int
}

// NewTable creates a connection table. params[i] is used for port i.
func NewTable(clock engine.Clock, hooks Hooks, params []PortParams) *Table {
	return &Table{
		clock:     clock,
		hooks:     hooks,
		params:    params,
		conns:     make(map[connKey]*Conn),
		portCount: len(params),
	}
}

// Hooks returns a pointer to the table's Hooks struct so tests can mutate
// individual fields (e.g. set Defer) after construction.
func (t *Table) Hooks() *Hooks {
	return &t.hooks
}

// portParams returns the PortParams for the given port (clamped to last if out of range).
func (t *Table) portParams(port int) PortParams {
	if port < 0 || len(t.params) == 0 {
		return PortParams{Paclen: maxIFrameInfo, N2Retry: 10, T1: 3 * time.Second, T1Setup: defaultT1Setup, T1Floor: defaultT1Setup}
	}
	if port >= len(t.params) {
		return t.params[len(t.params)-1]
	}
	return t.params[port]
}

// Get returns the Conn for (port, local, remote), or nil if none exists.
func (t *Table) Get(port int, local, remote string) *Conn {
	return t.conns[makeKey(port, local, remote)]
}

// getOrCreate returns an existing Conn or creates one. Returns nil if the
// connection limit is reached (tncd.py:1228-1237).
func (t *Table) getOrCreate(port int, local, remote string) *Conn {
	k := makeKey(port, local, remote)
	if c, ok := t.conns[k]; ok {
		return c
	}
	if len(t.conns) >= maxConnections {
		return nil
	}
	c := newConn(k.port, k.local, k.remote)
	c.t1Value = t.portParams(port).T1
	t.conns[k] = c
	t.notifyPortSessions(port)
	return c
}

// notifyPortSessions reports the port's current connection count to the hook.
// Called from getOrCreate and remove -- the only two places the table changes
// size -- so a caller cannot miss a transition by taking a different path to
// creating or dropping a connection.
func (t *Table) notifyPortSessions(port int) {
	if t.hooks.PortSessions == nil {
		return
	}
	n := 0
	for k := range t.conns {
		if k.port == port {
			n++
		}
	}
	t.hooks.PortSessions(port, n)
}

// remove deletes a connection from the table and cancels all its timers.
// Mirrors tncd.py:_cancel_t1/_cancel_t2/_cancel_t3 called from remove_connection.
func (t *Table) remove(port int, local, remote string) {
	k := makeKey(port, local, remote)
	c, ok := t.conns[k]
	if !ok {
		return
	}
	c.t1 = cancelTimer(c.t1)
	c.t2 = cancelTimer(c.t2)
	c.t3 = cancelTimer(c.t3)
	delete(t.conns, k)
	t.notifyPortSessions(port)
}

// removeConn removes by conn pointer (for cases where we already have the conn).
func (t *Table) removeConn(c *Conn) {
	t.remove(c.Port, c.Local, c.Remote)
}

// startT1 starts (or restarts) the T1 retransmit/poll timer for conn.
// Uses c.t1Value, which the Karn/SRTT estimator keeps up to date.
// The closure captures the returned *Timer in self so that a stale expiry
// (fired after a subsequent startT1 replaced c.t1) is a no-op (I4 guard).
func (t *Table) startT1(c *Conn) {
	c.t1 = cancelTimer(c.t1)
	d := c.t1Value
	if d <= 0 {
		d = t.portParams(c.Port).T1
	}
	conn := c
	var self *engine.Timer
	self = t.clock.After(d, func() {
		if c.t1 != self {
			return // stale — a newer startT1 replaced us
		}
		t.t1Expired(conn)
	})
	c.t1 = self
}

// cancelT1 stops the T1 timer if running.
func cancelT1(c *Conn) {
	c.t1 = cancelTimer(c.t1)
}

// scheduleT2 schedules a delayed RR (T2 timer), resetting any existing timer.
// A burst of in-sequence I-frames results in a single RR after the last frame.
// Mirrors tncd.py:1423-1436 (_schedule_t2).
// The closure captures self so that a stale expiry is a no-op (I4 guard).
func (t *Table) scheduleT2(c *Conn, src, dst string) {
	c.t2 = cancelTimer(c.t2)
	c.t2Src = src
	c.t2Dst = dst
	pp := t.portParams(c.Port)
	conn := c
	var self *engine.Timer
	self = t.clock.After(pp.T2, func() {
		if c.t2 != self {
			return // stale
		}
		t.t2Expired(conn)
	})
	c.t2 = self
}

// cancelT2 cancels the T2 delayed ACK timer.
func cancelT2(c *Conn) {
	c.t2 = cancelTimer(c.t2)
}

// t2Expired fires the delayed RR: send RR F=0 with current recvSeq.
// Mirrors tncd.py:1445-1498 (_t2_expired, _send_delayed_rr).
func (t *Table) t2Expired(c *Conn) {
	c.t2 = nil
	if c.State != Connected {
		return
	}
	// Send RR response F=0 with current V(R).
	rr := respFrame(c.t2Src, c.t2Dst, c.Via, ax25.RR, false)
	rr.NR = c.recvSeq
	t.sendFrame(c.Port, rr)
}

// startT3 starts (or restarts) the T3 inactive link timer.
// Mirrors tncd.py:1453-1463 (_start_t3).
// The closure captures self so that a stale expiry is a no-op (I4 guard).
func (t *Table) startT3(c *Conn) {
	c.t3 = cancelTimer(c.t3)
	pp := t.portParams(c.Port)
	if pp.T3 <= 0 {
		return
	}
	conn := c
	var self *engine.Timer
	self = t.clock.After(pp.T3, func() {
		if c.t3 != self {
			return // stale
		}
		t.t3Expired(conn)
	})
	c.t3 = self
}

// t3Expired fires the T3 liveness poll: sends RR P=1 command and starts T1.
// Mirrors tncd.py:1471-1487 (_t3_expired).
func (t *Table) t3Expired(c *Conn) {
	c.t3 = nil
	if c.State != Connected {
		return
	}
	// Send RR P=1 command (liveness poll) and enter timer recovery: T1 now
	// re-polls up to N2 times, so a dead idle link is eventually torn down.
	c.t1Polls = 0
	t.sendEnquiry(c)
	t.startT1(c)
}

// sendEnquiry sends an RR P=1 command (a poll demanding RR/RNR F=1) and marks
// the link as awaiting that answer (timer recovery).
func (t *Table) sendEnquiry(c *Conn) {
	rr := cmdFrame(c.Remote, c.Local, c.Via, ax25.RR, true)
	rr.NR = c.recvSeq
	t.sendFrame(c.Port, rr)
	c.polling = true
}

// sendRRResponse answers a poll: it sends RR F=1 (response, PF=true) with
// conn.recvSeq. A response to a P=1 poll is mandatory in AX.25 (the peer's T1
// recovery checkpoint), so it is sent unconditionally and never suppressed.
//
// This is the reference behavior: Dire Wolf's enquiry_response (ax25_link.c,
// per X.25 2.4.6.11) always answers a poll with F=1, even for a duplicate or
// out-of-range I-frame whose data is discarded. Flood avoidance on shared
// half-duplex channels belongs on the *unsolicited* ack path (the T2 delayed
// ack, scheduleT2), which coalesces N(R) updates — never on poll responses.
// A time-window guard here (the former 3s dup-RR suppressor) deadlocks a slow
// link: when N(R) is stuck on a retransmit, every poll within the window is
// swallowed, so the peer's T1 keeps firing and it retransmits forever.
func (t *Table) sendRRResponse(c *Conn, src, dst string) {
	rr := respFrame(src, dst, c.Via, ax25.RR, true)
	rr.NR = c.recvSeq
	t.sendFrame(c.Port, rr)
}

// defer_ posts fn via Hooks.Defer (mirrors asyncio loop.call_soon). If
// Hooks.Defer is nil, fn is called synchronously (test default).
func (t *Table) defer_(fn func()) {
	if t.hooks.Defer != nil {
		t.hooks.Defer(fn)
	} else {
		fn()
	}
}

// t1Expired handles T1 timer expiry (tncd.py:1500-1539 for CONNECTING case,
// tncd.py:1541-1579 for Connected state).
func (t *Table) t1Expired(c *Conn) {
	c.t1 = nil
	pp := t.portParams(c.Port)

	if c.State == Disconnecting {
		// DISC retransmission while awaiting UA/DM. Dire Wolf retries DISC on
		// T1 exactly like SABM, so a lost DISC does not wedge the link. (tncd.py
		// and the pre-fix code had no branch here: the timer fired once, was not
		// re-armed, and the conn zombied in the table forever.)
		c.t1Polls++
		if c.t1Polls > pp.N2Retry {
			// N2 exhausted — give up. On a healthy link the peer is gone; on a
			// wedged link the resends were harmlessly dropped. This removal is
			// purely local cleanup, no on-air delivery is required.
			c.State = Disconnected
			if t.hooks.Disconnected != nil {
				t.hooks.Disconnected(c)
			}
			t.removeConn(c)
			return
		}
		// Connection-phase retransmits use a FIXED T1 (no Karn backoff), same
		// reasoning as the Connecting branch.
		c.t1Value = setupT1(pp.T1Setup, len(c.Via))
		f := cmdFrame(c.Remote, c.Local, c.Via, ax25.DISC, true)
		t.sendFrame(c.Port, f)
		t.startT1(c)
		return
	}

	if c.State == Connecting {
		// SABM/SABME retransmission while waiting for UA (AX.25 6.3.1)
		// tncd.py:1512-1539
		c.t1Polls++
		maxV22 := pp.N2Retry / 3
		if c.modulo == 128 && !c.triedFallback && c.t1Polls >= maxV22 {
			// Direwolf MAXV22 hack: after maxV22 SABMEs, continue as SABM
			// without resetting the retry counter.
			c.modulo = 8
			c.triedFallback = true
		}
		if c.t1Polls > pp.N2Retry {
			// N2 exhausted — give up
			c.State = Disconnected
			if t.hooks.ConnectFailed != nil {
				t.hooks.ConnectFailed(c, FailTimeout)
			}
			t.removeConn(c)
			return
		}
		// Connection-setup retransmits use a FIXED T1. Karn's exponential
		// backoff is for the data (information-transfer) phase only — the AX.25
		// spec and Dire Wolf's select_t1_value keep t1v ~constant while awaiting
		// a UA. Doubling here makes SABM/SABME retries too sparse (13→26→52s),
		// so a timing-marginal radio's narrow acceptance window is missed and
		// the peer never sees a retry in time. Reset to the base so every retry
		// is evenly spaced.
		c.t1Value = setupT1(pp.T1Setup, len(c.Via))
		if c.modulo == 128 {
			t.sendSABME(c)
		} else {
			t.sendSABM(c)
		}
		t.startT1(c)
		return
	}

	// Connected state: data-phase T1 (tncd.py:1541-1579). T1 only runs here
	// while something is awaited — unacked I-frames or an unanswered T3 poll —
	// so an expiry with an empty retransmit buffer is a lost poll answer and
	// must re-poll (and count toward N2) rather than be ignored.
	if c.State != Connected {
		return
	}
	c.t1Polls++

	// N2 retry limit: disconnect after too many unanswered polls.
	if c.t1Polls > pp.N2Retry {
		c.State = Disconnected
		if t.hooks.Disconnected != nil {
			t.hooks.Disconnected(c)
		}
		t.removeConn(c)
		return
	}

	// Poll #1: send RR P=1 only; poll #2+: also retransmit.
	t.sendEnquiry(c)

	if c.t1Polls > 1 {
		t.retransmitFrom(c, c.lastAcked)
	}

	// Karn: exponential backoff on timeout (tncd.py:1575-1578).
	if c.t1Value > 0 {
		c.t1Value *= 2
		const t1Ceil = 60 * time.Second
		if c.t1Value > t1Ceil {
			c.t1Value = t1Ceil
		}
	}
	t.startT1(c)
}

// isLocal reports whether call is one of our registered callsigns on port.
// When Hooks.IsLocal is nil, returns true (permissive default: keeps all
// existing l2 tests passing unchanged without setting the hook).
func (t *Table) isLocal(port int, call string) bool {
	if t.hooks.IsLocal == nil {
		return true
	}
	return t.hooks.IsLocal(port, call)
}

// sendFrame stamps the modulo on outgoing I/S frames (if not already set)
// then calls hooks.SendAX25.
func (t *Table) sendFrame(port int, f *ax25.Frame) {
	if f.Modulo == 0 && (f.Type == ax25.I || f.Type.IsS()) {
		f.Modulo = uint8(t.ModuloFor(port, f.Src.String(), f.Dst.String()))
	}
	if t.hooks.SendAX25 != nil {
		t.hooks.SendAX25(port, f)
	}
}

// ModuloFor returns the negotiated modulo (8 or 128) for the connection
// addressed by (port, local, remote), or 8 if there is no such connection.
// The bridge uses this to decode inbound I/S control fields at the right width.
func (t *Table) ModuloFor(port int, local, remote string) int {
	if c := t.Get(port, local, remote); c != nil {
		return int(c.modulo)
	}
	return 8
}

// cmdFrame builds a command frame (dst C-bit=1, src C-bit=0).
// Mirrors tncd.py _cmd_frame().
func cmdFrame(dst, src string, via []string, typ ax25.FrameType, pf bool) *ax25.Frame {
	d, _ := ax25.ParseAddress(dst)
	s, _ := ax25.ParseAddress(src)
	f := &ax25.Frame{
		Dst:     d,
		Src:     s,
		Type:    typ,
		PF:      pf,
		Command: true, // command frame
	}
	for _, v := range via {
		a, _ := ax25.ParseAddress(v)
		f.Via = append(f.Via, a)
	}
	return f
}

// respFrame builds a response frame (dst C-bit=0, src C-bit=1).
// Mirrors tncd.py _resp_frame().
func respFrame(dst, src string, via []string, typ ax25.FrameType, pf bool) *ax25.Frame {
	d, _ := ax25.ParseAddress(dst)
	s, _ := ax25.ParseAddress(src)
	f := &ax25.Frame{
		Dst:     d,
		Src:     s,
		Type:    typ,
		PF:      pf,
		Command: false, // response frame
	}
	for _, v := range via {
		a, _ := ax25.ParseAddress(v)
		f.Via = append(f.Via, a)
	}
	return f
}

// sendSABM sends a SABM P=1 (mod-8 connect) command frame to the remote.
func (t *Table) sendSABM(c *Conn) {
	f := cmdFrame(c.Remote, c.Local, c.Via, ax25.SABM, true)
	t.sendFrame(c.Port, f)
}

// sendSABME sends a SABME P=1 command frame to the remote (AX.25 v2.2 mod-128).
func (t *Table) sendSABME(c *Conn) {
	f := cmdFrame(c.Remote, c.Local, c.Via, ax25.SABME, true)
	t.sendFrame(c.Port, f)
}

// enterConnected does the bookkeeping common to every way a link becomes
// established, and in particular hands T1 back to the DATA-phase value.
//
// This matters more than it looks. T1Setup (FRACK, 3s by default) is sized for a
// handshake: a ~17-byte command and a ~17-byte UA, a quarter of a second of air
// time. The data phase is a different problem -- at 1200 baud a window of
// 254-byte I-frames takes several seconds just to transmit -- and T1 was left
// holding the setup value until the first round-trip measurement replaced it.
//
// On a slow link that is long enough to do real damage. T1 fires before the
// first window is even on the air, tncd retransmits frames that are still in
// flight or already acknowledged, and a mod-8 receiver whose N(R) has moved on
// counts those as NEW data. The result is an assembled image longer than what
// was sent: measured against a BPQ gateway, 10,275 bytes received for an 8,175
// byte message, failing the application checksum while every AX.25 FCS stayed
// valid. Five of six large uploads failed that way; with the data-phase T1
// restored, none did.
func (t *Table) enterConnected(c *Conn) {
	c.State = Connected
	c.t1Value = t.portParams(c.Port).T1
}

// fallbackToSABM downgrades a still-connecting mod-128 attempt to mod-8 and
// resends SABM. Mirrors Direwolf set_version_2_0 + resend. Returns true if a
// downgrade happened.
func (t *Table) fallbackToSABM(c *Conn) bool {
	if c.modulo != 128 || c.triedFallback {
		return false
	}
	c.modulo = 8
	c.triedFallback = true
	t.sendSABM(c)
	t.startT1(c)
	return true
}

// Connect initiates an outgoing AX.25 connection (tncd.py:274-304).
// Sends SABME P=1 on AX.25 v2.2 ports, SABM P=1 on v2.0 ports.
// Sets state=Connecting, starts T1. Returns an error if the connection table is full.
// getOrCreate may return a reused Conn from a prior session; all relevant state
// (including triedFallback) is reset so that a fresh v2.2 attempt starts clean.
func (t *Table) Connect(port int, local, remote string, via []string) (*Conn, error) {
	// Every address must encode: an unparseable one would otherwise go on the
	// air as a blank (all-space) callsign.
	for _, call := range append([]string{local, remote}, via...) {
		if _, err := ax25.ParseAddress(call); err != nil {
			return nil, fmt.Errorf("l2: connect %s -> %s: %w", local, remote, err)
		}
	}
	c := t.getOrCreate(port, local, remote)
	if c == nil {
		return nil, fmt.Errorf("l2: connection limit reached (%d)", maxConnections)
	}
	c.State = Connecting
	c.resetSeqs()
	c.t1Polls = 0
	c.triedFallback = false
	c.Via = via
	c.t1Value = setupT1(t.portParams(port).T1Setup, len(via))

	if t.portParams(port).AX25Version >= 22 {
		c.modulo = 128
		t.sendSABME(c)
	} else {
		c.modulo = 8
		t.sendSABM(c)
	}
	t.startT1(c)
	return c, nil
}

// Disconnect initiates a graceful disconnect (tncd.py: DISC P=1, Disconnecting).
func (t *Table) Disconnect(c *Conn) {
	cancelT1(c)
	c.State = Disconnecting
	c.t1Polls = 0
	f := cmdFrame(c.Remote, c.Local, c.Via, ax25.DISC, true)
	t.sendFrame(c.Port, f)
	t.startT1(c)
}

// maxOutboundQueue is the maximum number of frames in the outbound queue
// before drops occur (tncd.py MAX_OUTBOUND_QUEUE = 512).
const maxOutboundQueue = 512

// maxIFrameInfo is the default max info field size for an I-frame (N1).
const maxIFrameInfo = 256

// SendData fragments payload into ≤128-byte chunks, queues (chunk, pid), then
// calls drainOutbound. Chunks that do not fit in the 512-entry queue are
// dropped; the count is returned so the caller can report the loss.
// Mirrors tncd.py:366-389 ('D' handler).
func (t *Table) SendData(c *Conn, pid uint8, data []byte) (dropped int) {
	if len(data) == 0 {
		data = []byte{}
	}
	maxInfo := t.portParams(c.Port).Paclen
	if maxInfo <= 0 {
		maxInfo = maxIFrameInfo
	}
	// Fragment into maxInfo-byte chunks.
	chunks := make([][]byte, 0, (len(data)+maxInfo-1)/maxInfo)
	if len(data) == 0 {
		chunks = append(chunks, []byte{})
	} else {
		for i := 0; i < len(data); i += maxInfo {
			end := i + maxInfo
			if end > len(data) {
				end = len(data)
			}
			chunks = append(chunks, data[i:end])
		}
	}

	for i, chunk := range chunks {
		if len(c.outQueue) >= maxOutboundQueue {
			// Queue full — drop remaining chunks.
			dropped = len(chunks) - i
			break
		}
		c.outQueue = append(c.outQueue, outEntry{pid: pid, data: chunk})
	}
	t.drainOutbound(c)
	return dropped
}

// Outstanding returns unacked + len(outQueue), the Y-frame fix.
// Mirrors tncd.py:432-449.
func (t *Table) Outstanding(c *Conn) int {
	return int(c.unacked) + len(c.outQueue)
}

// drainOutbound sends queued I-frames while the outbound window has space.
// Coalesces adjacent same-PID chunks up to 256 bytes.
// Mirrors tncd.py:1339-1385.
func (t *Table) drainOutbound(c *Conn) {
	if c.remoteBusy {
		return
	}
	pp := t.portParams(c.Port)
	maxInfo := pp.Paclen
	if maxInfo <= 0 {
		maxInfo = maxIFrameInfo
	}
	sentAny := false
	for len(c.outQueue) > 0 && int(c.unacked) < pp.MaxWindow {
		// Pop first entry.
		entry := c.outQueue[0]
		c.outQueue = c.outQueue[1:]
		// Copy the head chunk before coalescing: entry.data may be a subslice
		// of a caller-supplied payload, and append below could otherwise write
		// into that backing array when it has spare capacity (corrupting the
		// caller's buffer or a neighbour entry). Copying keeps the coalescing
		// append on a fresh allocation whenever it grows past the head.
		chunk := append([]byte(nil), entry.data...)
		pid := entry.pid

		// Coalesce adjacent entries with the same PID up to 256 bytes.
		for len(c.outQueue) > 0 && len(chunk) < maxInfo {
			next := c.outQueue[0]
			if next.pid != pid || len(chunk)+len(next.data) > maxInfo {
				break
			}
			c.outQueue = c.outQueue[1:]
			chunk = append(chunk, next.data...)
		}

		ns := c.sendSeq
		f := iFrame(c, ns, pid, chunk)

		// Store raw bytes in retransmitBuf, record first-TX timestamp.
		raw := f.Bytes()
		c.retransmitBuf[ns] = raw
		c.iframeTimestamps[ns] = t.clock.Now()
		c.sendSeq = (ns + 1) % c.modulo
		c.unacked++
		sentAny = true

		t.sendFrame(c.Port, f)
	}
	if sentAny {
		// Outgoing I-frames piggyback N(R): cancel T2 delayed ACK, start T1.
		c.t2 = cancelTimer(c.t2)
		t.startT1(c)
	}
}

// ackFrames processes a cumulative ACK: purge retransmit buffer, update SRTT,
// restart or cancel T1, then drain outbound queue.
// Mirrors tncd.py:1581-1616.
func (t *Table) ackFrames(c *Conn, nr uint8) {
	newlyAcked := (nr - c.lastAcked) % c.modulo
	// Valid N(R) lies in [V(A), V(S)] (Dire Wolf is_good_nr). Anything else —
	// a backwards N(R) from a retransmission, or one acking frames we never
	// sent — would corrupt V(A), so it is ignored.
	if outstanding := (c.sendSeq - c.lastAcked) % c.modulo; newlyAcked > outstanding {
		return
	}
	if newlyAcked == 0 {
		return
	}

	c.t1Polls = 0 // remote responded — reset consecutive poll counter

	// Karn RTT sampling from first-TX timestamps (skip retransmitted frames).
	now := t.clock.Now()
	seq := c.lastAcked
	for i := uint8(0); i < newlyAcked; i++ {
		if sendTime, ok := c.iframeTimestamps[seq]; ok {
			delete(c.iframeTimestamps, seq)
			rtt := now.Sub(sendTime)
			t.updateSRTT(c, rtt)
		}
		seq = (seq + 1) % c.modulo
	}

	// Purge retransmit buffer for ACKed sequence numbers.
	seq = c.lastAcked
	for i := uint8(0); i < newlyAcked; i++ {
		delete(c.retransmitBuf, seq)
		seq = (seq + 1) % c.modulo
	}

	c.lastAcked = nr
	if int(c.unacked) > int(newlyAcked) {
		c.unacked -= newlyAcked
	} else {
		c.unacked = 0
	}

	if len(c.retransmitBuf) > 0 {
		t.startT1(c)
	} else {
		c.t1 = cancelTimer(c.t1)
	}
	t.drainOutbound(c)
}

// updateSRTT updates smoothed RTT and variance per Karn's algorithm (RFC 2988).
// Mirrors tncd.py:1404-1421.
func (t *Table) updateSRTT(c *Conn, rtt time.Duration) {
	// The floor comes from the port's link speed, not a constant. With a flat
	// 3s floor the estimator settled below the time needed to transmit a
	// window on a 1200-baud link, so tncd retransmitted into its own in-flight
	// data; a mod-8 receiver whose N(R) had advanced then counted the
	// retransmission as NEW data and the assembled image came out ~1900 bytes
	// long. See TestT1FloorRespectsLinkSpeed.
	//
	// The samples that drive the estimator down are themselves misleading here:
	// RTT is measured on whatever gets acked, and the small FC/FS exchanges
	// around a Winlink transfer return in about a second, so an estimator with
	// no link-aware floor happily sizes the data phase from handshake traffic.
	t1Floor := t.portParams(c.Port).T1Floor
	if t1Floor <= 0 {
		t1Floor = defaultT1Setup
	}
	const t1Ceil = 60 * time.Second
	if c.srtt == 0 {
		// First measurement.
		c.srtt = rtt
		c.rttvar = rtt / 2
	} else {
		// α = 7/8, β = 3/4 (RFC 2988 / Jacobson/Karels).
		diff := c.srtt - rtt
		if diff < 0 {
			diff = -diff
		}
		c.rttvar = (3*c.rttvar + diff) / 4
		c.srtt = (7*c.srtt + rtt) / 8
	}
	t1 := c.srtt + 4*c.rttvar
	if t1 < t1Floor {
		t1 = t1Floor
	}
	if t1 > t1Ceil {
		t1 = t1Ceil
	}
	c.t1Value = t1
}

// retransmitFrom retransmits all buffered I-frames from fromSeq onward,
// rebuilding each with the current N(R) to piggyback newer ACKs, and
// dropping RTT timestamps (Karn's algorithm).
// Mirrors tncd.py:1618-1640.
func (t *Table) retransmitFrom(c *Conn, fromSeq uint8) {
	t.retransmitRange(c, fromSeq, c.sendSeq)
}

// retransmitRange retransmits buffered I-frames in [fromSeq, toSeq).
func (t *Table) retransmitRange(c *Conn, fromSeq, toSeq uint8) {
	seq := fromSeq
	for seq != toSeq {
		raw, ok := c.retransmitBuf[seq]
		if !ok {
			break
		}
		// Parse the stored frame to extract NS/PID/Info.
		orig, err := ax25.ParseModulo(raw, int(c.modulo))
		if err != nil {
			break
		}
		// Rebuild with current N(R) (piggyback-acknowledge received frames).
		f := iFrame(c, orig.NS, orig.PID, orig.Info)
		f.PF = orig.PF
		// Update retransmitBuf with rebuilt frame.
		c.retransmitBuf[seq] = f.Bytes()
		// Karn: discard RTT sample for retransmitted frames.
		delete(c.iframeTimestamps, seq)
		t.sendFrame(c.Port, f)
		seq = (seq + 1) % c.modulo
	}
}

// iFrame builds an I-frame command for conn c carrying the current N(R), the
// link's modulo and its digipeater path. The one place I-frames are built, so
// a new send path cannot forget the path or the modulo.
func iFrame(c *Conn, ns, pid uint8, info []byte) *ax25.Frame {
	f := cmdFrame(c.Remote, c.Local, c.Via, ax25.I, false)
	f.NS = ns
	f.NR = c.recvSeq
	f.PID = pid
	f.Info = info
	f.Modulo = c.modulo
	return f
}

// OnFrame dispatches an inbound AX.25 frame to the appropriate handler.
// The frame's Dst is our local call, Src is the remote.
// (tncd.py:1684-1700 dispatch table)
func (t *Table) OnFrame(port int, f *ax25.Frame) {
	// src = who sent it (remote), dst = who it's addressed to (our local call)
	src := f.Src.String()
	dst := f.Dst.String()

	switch f.Type {
	case ax25.SABM:
		t.dispatchSABM(port, f, src, dst)
	case ax25.SABME:
		t.dispatchSABME(port, f, src, dst)
	case ax25.UA:
		t.dispatchUA(port, f, src, dst)
	case ax25.DM:
		t.dispatchDM(port, f, src, dst)
	case ax25.DISC:
		t.dispatchDISC(port, f, src, dst)
	case ax25.FRMR:
		t.dispatchFRMR(port, f, src, dst)
	case ax25.I:
		t.dispatchI(port, f, src, dst)
	case ax25.RR, ax25.RNR, ax25.REJ, ax25.SREJ:
		t.dispatchS(port, f, src, dst)
	case ax25.XID:
		t.dispatchXID(port, f, src, dst)
	}

	// Reset T3 inactive link timer on any received frame for a Connected conn.
	// Mirrors tncd.py:1707-1711 (on_kiss_frame level, after dispatch).
	if c := t.Get(port, dst, src); c != nil && c.State == Connected {
		t.startT3(c)
	}
}

// RemoveOwned sends DISC for all connections owned by the given owner, then
// removes them from the table. Mirrors tncd.py:1202-1220 (remove_client).
func (t *Table) RemoveOwned(owner any) {
	var toRemove []*Conn
	for _, c := range t.conns {
		if c.Owner == owner {
			toRemove = append(toRemove, c)
		}
	}
	for _, c := range toRemove {
		c.t1 = cancelTimer(c.t1)
		c.t2 = cancelTimer(c.t2)
		c.t3 = cancelTimer(c.t3)
		if c.State == Connected || c.State == Connecting {
			f := cmdFrame(c.Remote, c.Local, c.Via, ax25.DISC, true)
			t.sendFrame(c.Port, f)
		}
		t.removeConn(c)
	}
}

// PortOffline handles a port going offline: cancels all timers, fires
// Disconnected for Connected/Connecting/Disconnecting conns on that port, and
// removes them. Disconnecting conns are reaped too: with the port dead the UA
// can *never* arrive (the port transmits nothing), so local reaping is the
// only possible cleanup.
// Mirrors tncd.py:1246-1264 (_port_went_offline).
func (t *Table) PortOffline(port int) {
	var toRemove []*Conn
	for _, c := range t.conns {
		if c.Port == port &&
			(c.State == Connected || c.State == Connecting || c.State == Disconnecting) {
			toRemove = append(toRemove, c)
		}
	}
	for _, c := range toRemove {
		c.t1 = cancelTimer(c.t1)
		c.t2 = cancelTimer(c.t2)
		c.t3 = cancelTimer(c.t3)
		if t.hooks.Disconnected != nil {
			t.hooks.Disconnected(c)
		}
		t.removeConn(c)
	}
}

// --- Frame dispatch handlers ---

// dispatchSABM handles an incoming SABM (tncd.py:1844-1912).
func (t *Table) dispatchSABM(port int, f *ax25.Frame, src, dst string) {
	// Overheard-frame suppression: if this pair has a connection on a
	// different port, silently drop (tncd.py:1850-1856).
	for otherPort, c := range t.connsByPair(dst, src) {
		if otherPort != port && (c.State == Connecting || c.State == Connected) {
			return
		}
	}

	// Foreign-SABM suppression: if dst is not one of our registered callsigns,
	// silently drop — no UA, no DM, no connection created. On a shared channel,
	// connect requests addressed to other stations must not be answered.
	// Deliberate divergence from tncd.py:1844-1912 (shared-channel courtesy).
	if !t.isLocal(port, dst) {
		return
	}

	// Capture digipeater path (reversed for return direction, tncd.py:1858-1859).
	incomingVia := addrSliceToStrings(f.Via)
	returnVia := reversed(incomingVia)

	// Get or create the connection (local=dst, remote=src).
	c := t.getOrCreate(port, dst, src)
	if c == nil {
		// Connection limit — reject with DM (tncd.py:1865-1873).
		dm := respFrame(src, dst, returnVia, ax25.DM, f.PF)
		t.sendFrame(port, dm)
		return
	}

	// Send UA response echoing P flag (tncd.py:1875-1883).
	ua := respFrame(src, dst, returnVia, ax25.UA, f.PF)
	t.sendFrame(port, ua)

	// Full state reset (tncd.py:1884-1896). SABM always establishes mod-8,
	// even on a conn a previous SABME left at mod-128.
	c.Via = returnVia
	t.enterConnected(c)
	c.modulo = 8
	c.resetSeqs()
	c.t1 = cancelTimer(c.t1)
	c.t2 = cancelTimer(c.t2)
	c.t3 = cancelTimer(c.t3)

	// Notify hook (tncd.py:1907-1912).
	if t.hooks.Connected != nil {
		c.incoming = true
		t.hooks.Connected(c, true)
	}
}

// dispatchSABME handles SABME (tncd.py:1686-1695 for the DM-reject path;
// extended here for AX.25 v2.2 accept).
// On a 2.0-only port: reject with DM P=1 so the peer (e.g. Direwolf) retries SABM.
// On a 2.2 port: accept with UA, set modulo=128, fire the Connected hook.
// Like SABM/I/DISC, the response is gated on the destination being one of
// our registered callsigns; answering foreign SABMEs would transmit DM into
// other stations' sessions on a shared channel.
func (t *Table) dispatchSABME(port int, f *ax25.Frame, src, dst string) {
	// Overheard-frame suppression: if this pair has a connection on a
	// different port, silently drop (mirrors dispatchSABM logic).
	for otherPort, c := range t.connsByPair(dst, src) {
		if otherPort != port && (c.State == Connecting || c.State == Connected) {
			return
		}
	}

	if !t.isLocal(port, dst) {
		return
	}
	if t.portParams(port).AX25Version < 22 {
		// 2.0-only port: reject; the peer (e.g. Direwolf) then retries SABM.
		dm := respFrame(src, dst, nil, ax25.DM, true)
		t.sendFrame(port, dm)
		return
	}
	// Accept mod-128. Mirror dispatchSABM but set modulo = 128.
	incomingVia := addrSliceToStrings(f.Via)
	returnVia := reversed(incomingVia)
	c := t.getOrCreate(port, dst, src)
	if c == nil {
		dm := respFrame(src, dst, returnVia, ax25.DM, f.PF)
		t.sendFrame(port, dm)
		return
	}
	ua := respFrame(src, dst, returnVia, ax25.UA, f.PF)
	t.sendFrame(port, ua)
	c.Via = returnVia
	t.enterConnected(c)
	c.modulo = 128
	c.resetSeqs()
	c.t1 = cancelTimer(c.t1)
	c.t2 = cancelTimer(c.t2)
	c.t3 = cancelTimer(c.t3)
	if t.hooks.Connected != nil {
		c.incoming = true
		t.hooks.Connected(c, true)
	}
}

// dispatchUA handles incoming UA (tncd.py:1914-1944).
func (t *Table) dispatchUA(port int, f *ax25.Frame, src, dst string) {
	// src=remote sent UA, dst=local received it
	c := t.Get(port, dst, src)
	if c == nil {
		return
	}

	switch c.State {
	case Connecting:
		// Outgoing connect confirmed (tncd.py:1922-1934).
		c.t1 = cancelTimer(c.t1)
		t.enterConnected(c)
		c.sendSeq = 0
		c.recvSeq = 0
		c.t1Polls = 0
		if t.hooks.Connected != nil {
			c.incoming = false
			t.hooks.Connected(c, false)
		}
		// Initiator XID: the answering peer does not send XID, so we must, to
		// negotiate SREJ for the (download) direction where tncd is the receiver.
		if t.portParams(port).SREJ && c.modulo == 128 {
			t.sendXIDCommand(c)
		}

	case Disconnecting:
		// Disconnect confirmed (tncd.py:1936-1944).
		if t.hooks.Disconnected != nil {
			t.hooks.Disconnected(c)
		}
		t.removeConn(c)
	}
}

// dispatchDM handles incoming DM (tncd.py:1946-1961).
func (t *Table) dispatchDM(port int, f *ax25.Frame, src, dst string) {
	c := t.Get(port, dst, src)
	if c == nil {
		return
	}
	if c.State == Connecting && c.modulo == 128 && !c.triedFallback {
		t.fallbackToSABM(c)
		return
	}
	// A DM while awaiting our XID response = peer rejects XID; keep the
	// connection (do not tear it down over an XID the peer didn't understand).
	if c.State == Connected && c.xidPending {
		c.xidPending = false
		c.srejEnabled = false
		return
	}
	if c.State == Connecting {
		if t.hooks.ConnectFailed != nil {
			t.hooks.ConnectFailed(c, FailDM)
		}
	} else {
		if t.hooks.Disconnected != nil {
			t.hooks.Disconnected(c)
		}
	}
	t.removeConn(c)
}

// dispatchDISC handles remote-initiated DISC (tncd.py:1963-2004).
func (t *Table) dispatchDISC(port int, f *ax25.Frame, src, dst string) {
	c := t.Get(port, dst, src)

	if c == nil {
		// No connection on this port — check other ports for overheard suppression
		// (tncd.py:1968-1974).
		for otherPort, oc := range t.connsByPair(dst, src) {
			if otherPort != port &&
				(oc.State == Connecting || oc.State == Connected || oc.State == Disconnecting) {
				return
			}
		}
		// No connection anywhere — respond with DM, but only when dst is one
		// of our own callsigns. Foreign DISC on a shared channel must not
		// trigger a DM from us.
		// Deliberate divergence from tncd.py:1987-1994 (shared-channel courtesy).
		if t.isLocal(port, dst) {
			dm := respFrame(src, dst, nil, ax25.DM, f.PF)
			t.sendFrame(port, dm)
		}
		return
	}

	// Connection exists — respond with UA (tncd.py:1979-1985).
	ua := respFrame(src, dst, c.Via, ax25.UA, f.PF)
	t.sendFrame(port, ua)

	if t.hooks.Disconnected != nil {
		t.hooks.Disconnected(c)
	}
	t.removeConn(c)
}

// dispatchFRMR handles incoming FRMR (tncd.py:2006-2032).
// Resets the connection and sends a fresh SABM.
func (t *Table) dispatchFRMR(port int, f *ax25.Frame, src, dst string) {
	c := t.Get(port, dst, src)
	if c != nil && c.State == Connecting && c.modulo == 128 && !c.triedFallback {
		t.fallbackToSABM(c)
		return
	}
	// A FRMR while we are awaiting our XID response means the peer does not
	// understand XID (partial v2.2). Disable SREJ and keep the connection on
	// REJ — do NOT reset+re-SABM (that would re-send XID and loop). Mirrors
	// Direwolf's "FRMR of XID -> use v2.0 params, stay connected".
	if c != nil && c.State == Connected && c.xidPending {
		c.xidPending = false
		c.srejEnabled = false
		return
	}
	if c == nil || c.State != Connected {
		return
	}
	// Reset sequence numbers and buffers (tncd.py:2015-2025) but NOT remoteBusy.
	// Python's _dispatch_frmr resets: send/recv seqnos, unacked, lastAcked,
	// retransmitBuf, iframeTimestamps, outQueue — NOT remote_busy.
	// dispatchSABM also calls resetSeqs() which does reset remoteBusy, but
	// FRMR should preserve the remote flow-control state.
	busy := c.remoteBusy
	c.State = Connecting
	c.resetSeqs()
	c.remoteBusy = busy // FRMR preserves the remote flow-control state
	c.t1Polls = 0
	c.triedFallback = false
	c.t1 = cancelTimer(c.t1)
	c.t2 = cancelTimer(c.t2)
	c.t3 = cancelTimer(c.t3)

	// Re-establish at the link's modulo (tncd.py:2026-2031 always sent SABM,
	// which left a mod-128 conn talking 2-byte control fields to a peer that
	// had just agreed to mod-8). A peer that rejects the SABME still gets the
	// usual DM/FRMR -> SABM fallback.
	if c.modulo == 128 {
		t.sendSABME(c)
	} else {
		t.sendSABM(c)
	}
	t.startT1(c)
}

// dispatchI handles a received I-frame.
// Mirrors tncd.py:1735-1832 (_dispatch_i).
func (t *Table) dispatchI(port int, f *ax25.Frame, src, dst string) {
	// Find connection: local=dst (frame addressed to us), remote=src.
	c := t.Get(port, dst, src)

	// I-frame while CONNECTING: UA was lost OTA but remote accepted our SABM.
	// Promote to CONNECTED so the I-frame is processed normally below.
	// Mirrors tncd.py:1749-1759.
	if c != nil && c.State == Connecting {
		t.enterConnected(c)
		c.t1 = cancelTimer(c.t1) // the SABM retry timer; nothing is awaited now
		c.t1Polls = 0
		c.sendSeq = 0
		c.recvSeq = 0
		if t.hooks.Connected != nil {
			c.incoming = false
			t.hooks.Connected(c, false) // outgoing — we initiated
		}
	}

	if c == nil || c.State != Connected {
		// Check if this connection exists on a different port (overheard frame).
		// If so, silently drop. Mirrors tncd.py:1764-1770.
		for otherPort, oc := range t.connsByPair(dst, src) {
			if otherPort != port && (oc.State == Connecting || oc.State == Connected) {
				return
			}
		}
		// No active connection on any port — send DM if P=1 so remote knows,
		// but only when dst is one of our own callsigns. Foreign QSOs on a
		// shared channel must not trigger a DM from us.
		// Deliberate divergence from tncd.py:1771-1781 (shared-channel courtesy).
		if f.PF && t.isLocal(port, dst) {
			dm := respFrame(src, dst, nil, ax25.DM, true)
			t.sendFrame(port, dm)
		}
		return
	}

	// I-frames carry N(R) which implicitly ACKs our sent frames (always first).
	// Mirrors tncd.py:1783-1784.
	t.ackFrames(c, f.NR)

	pp := t.portParams(port)
	expectedNS := c.recvSeq

	if c.srejEnabled {
		gap := (f.NS - expectedNS) % c.modulo
		if gap > 0 {
			if int(gap) > pp.MaxWindow {
				// Outside window (or old duplicate): discard; honor a poll.
				if f.PF {
					cancelT2(c)
					t.sendRRResponse(c, src, dst)
				} else {
					t.scheduleT2(c, src, dst)
				}
				return
			}
			// In-window, ahead of V(R): buffer (copy — f.Info may alias) and
			// request every not-yet-requested hole in [V(R), N(S)).
			c.rxBuf[f.NS] = rxEntry{pid: f.PID, info: append([]byte(nil), f.Info...)}
			delete(c.srejSent, f.NS) // it arrived
			cancelT2(c)
			t.sendSREJHoles(c, src, dst, f.NS)
			return
		}
		// gap == 0: in sequence. Deliver, then flush contiguous buffered frames.
		delete(c.srejSent, f.NS)
		t.deliverData(c, f.PID, f.Info)
		c.recvSeq = (f.NS + 1) % c.modulo
		for {
			e, ok := c.rxBuf[c.recvSeq]
			if !ok {
				break
			}
			delete(c.rxBuf, c.recvSeq)
			delete(c.srejSent, c.recvSeq)
			t.deliverData(c, e.pid, e.info)
			c.recvSeq = (c.recvSeq + 1) % c.modulo
		}
		// No SREJ needed here: every hole below a still-buffered frame was
		// already requested when that frame arrived (recvSeq only advances, so
		// srejSent still covers it). Re-scanning to recvSeq+window would wrongly
		// SREJ trailing slots the sender has not transmitted.
		// Acknowledge the advanced V(R).
		if f.PF {
			cancelT2(c)
			t.sendRRResponse(c, src, dst)
		} else {
			t.scheduleT2(c, src, dst)
		}
		return
	}

	// --- SREJ not enabled: existing phase-3 REJ / go-back-N path (unchanged) ---
	if f.NS != expectedNS {
		// Out-of-sequence or duplicate frame.
		gap := (f.NS - expectedNS) % c.modulo
		if gap > 0 && int(gap) <= pp.MaxWindow && c.rejSent {
			// Already in reject exception: the REJ we sent covers this gap, so
			// don't ask again (every REJ makes the peer resend from V(R)).
			// A poll still gets its mandatory RR F=1. (Dire Wolf / AX.25 6.4.4.3)
			if f.PF {
				cancelT2(c)
				t.sendRRResponse(c, src, dst)
			}
		} else if gap > 0 && int(gap) <= pp.MaxWindow {
			// Gap within window: send REJ with V(R) = expected, echoing P/F,
			// and enter the reject exception condition.
			// Mirrors tncd.py:1791-1805.
			cancelT2(c)
			rej := respFrame(src, dst, c.Via, ax25.REJ, f.PF)
			rej.NR = expectedNS
			t.sendFrame(port, rej)
			c.rejSent = true
		} else {
			// True duplicate (or gap > window): discard data.
			// Mirrors tncd.py:1806-1815.
			if f.PF {
				cancelT2(c)
				t.sendRRResponse(c, src, dst)
			} else {
				t.scheduleT2(c, src, dst)
			}
		}
		return
	}
	c.rejSent = false // the requested frame arrived: exception cleared
	c.recvSeq = (f.NS + 1) % c.modulo
	if f.PF {
		cancelT2(c)
		t.sendRRResponse(c, src, dst)
	} else {
		t.scheduleT2(c, src, dst)
	}
	if t.hooks.Data != nil {
		data := f.Info
		if data == nil {
			data = []byte{}
		}
		t.hooks.Data(c, f.PID, data)
	}
}

// deliverData hands an in-sequence payload to the connection owner.
func (t *Table) deliverData(c *Conn, pid uint8, info []byte) {
	if t.hooks.Data == nil {
		return
	}
	if info == nil {
		info = []byte{}
	}
	t.hooks.Data(c, pid, info)
}

// sendSREJHoles sends a single SREJ (response) for each missing sequence number
// in [V(R), upto) that is not buffered and not already requested, recording each
// in srejSent (dedup). F=1 only on the SREJ for V(R) itself (also acknowledges).
//
// This is NOT a violation of having negotiated single-SREJ in XID: "single" vs
// "multi" SREJ distinguishes the frame *encoding*, not how many SREJ frames may
// be sent. Multi-SREJ packs the additional N(S) values into one SREJ's INFO
// field (the X.25 extension); single-SREJ sends a separate SREJ frame per
// missing N(S) — which is exactly what Dire Wolf's send_srej_frames does on its
// srej_single path ("Multi-SREJ not enabled. Send separate SREJ for each
// desired sequence number."), with F set only when N(R) == V(R) and dedup via
// outstanding_srej[]. Verified against wb2osz/direwolf src/ax25_link.c.
func (t *Table) sendSREJHoles(c *Conn, src, dst string, upto uint8) {
	for i := 0; i < int(c.modulo); i++ { // bound defends against a bad upto
		ns := (c.recvSeq + uint8(i)) % c.modulo
		if ns == upto {
			break
		}
		if _, buffered := c.rxBuf[ns]; buffered {
			continue
		}
		if c.srejSent[ns] {
			continue
		}
		srej := respFrame(src, dst, c.Via, ax25.SREJ, ns == c.recvSeq) // F=1 iff V(R)
		srej.NR = ns
		c.srejSent[ns] = true
		t.sendFrame(c.Port, srej)
	}
}

// dispatchS handles received S-frames (RR, RNR, REJ).
// Order: ackFrames first, then RNR/RR busy-flag, then REJ retransmit.
// The poll-response side (P=1 → deferred RR F=1) is handled via the T2
// delayed-ACK path rather than replying inline.
func (t *Table) dispatchS(port int, f *ax25.Frame, src, dst string) {
	// local=dst, remote=src
	c := t.Get(port, dst, src)
	if c == nil || c.State != Connected {
		return
	}

	// 1. Process cumulative ACK (always first, per Python order). An SREJ
	// acknowledges N(R)-1 only when F=1 (AX.25 2.2 4.3.2.4; Dire Wolf
	// srej_frame); an F=0 SREJ's N(R) just names the frame to resend.
	vsBefore := c.sendSeq // frames sent before this ack may drain new ones
	if f.Type != ax25.SREJ || f.PF {
		t.ackFrames(c, f.NR)
	}

	// Single-SREJ (v2.2): ackFrames above already acked <= N(R)-1 and left
	// frame N(R) in the retransmit buffer. Retransmit ONLY that frame — not
	// go-back-N. (We do send SREJ ourselves when negotiated — see
	// sendSREJHoles; this branch handles an SREJ we receive.)
	if f.Type == ax25.SREJ {
		c.remoteBusy = false
		if raw, ok := c.retransmitBuf[f.NR]; ok {
			if orig, err := ax25.ParseModulo(raw, int(c.modulo)); err == nil {
				rf := iFrame(c, orig.NS, orig.PID, orig.Info)
				c.retransmitBuf[f.NR] = rf.Bytes()
				delete(c.iframeTimestamps, f.NR) // Karn: no RTT sample on retransmit
				t.sendFrame(c.Port, rf)
			}
		}
		return // SREJ has no REJ/RR busy semantics beyond the above
	}

	// 2. RNR/RR busy-flag update.
	switch f.Type {
	case ax25.RNR:
		c.remoteBusy = true
	case ax25.RR:
		if c.remoteBusy {
			c.remoteBusy = false
			t.drainOutbound(c)
		}
	}

	// 3. REJ: retransmit from requested sequence number.
	if f.Type == ax25.REJ {
		c.remoteBusy = false
		t.retransmitFrom(c, f.NR)
	}

	// 4. Timer recovery: an F=1 response answers our RR P=1 enquiry. Resend
	// whatever is still unacked right away (REJ already did) instead of
	// waiting out another, doubled T1; with nothing outstanding the link is
	// healthy again, so stop T1.
	if !f.Command && f.PF && c.polling {
		c.polling = false
		if f.Type != ax25.REJ && !c.remoteBusy && len(c.retransmitBuf) > 0 {
			t.retransmitRange(c, c.lastAcked, vsBefore)
			t.startT1(c)
		}
		if len(c.retransmitBuf) == 0 {
			c.t1 = cancelTimer(c.t1)
			c.t1Polls = 0
		}
	}

	// Poll-response side: if P=1, respond with RR F=1.
	// Defer via Hooks.Defer so that any I-frames already queued on the event
	// loop (from the same KISS burst) are processed first, advancing recvSeq
	// before we build the response.
	// Exception: REJ P=1 responds immediately — a deferred call_soon would
	// invoke _retransmit_from a second time, flooding the TNC with duplicates.
	// Mirrors tncd.py:2098-2116 (_dispatch_s poll-response block).
	// Only a command polls; an F=1 response must not be answered.
	if f.PF && f.Command {
		// Re-lookup in case state changed above (tncd.py:2108).
		conn2 := t.Get(port, dst, src)
		if conn2 != nil && conn2.State == Connected {
			if f.Type == ax25.REJ {
				// Immediate: avoid double retransmit.
				t.sendRRResponse(conn2, src, dst)
			} else {
				// Deferred: let queued I-frames advance recvSeq first.
				c2 := conn2
				s, d := src, dst
				t.defer_(func() {
					if c2.State == Connected {
						t.sendRRResponse(c2, s, d)
					}
				})
			}
		}
	}
}

// sendXIDCommand sends an XID command (P=1) advertising our SREJ capability, so
// that when tncd is the connection initiator the peer (which does not initiate
// XID) learns we support SREJ and negotiates it. Mirrors Direwolf's initiator
// sending XID after UA.
func (t *Table) sendXIDCommand(c *Conn) {
	pp := t.portParams(c.Port)
	params := ax25.XIDParams{
		FullDuplex:       false,
		SREJ:             ax25.SREJSingle,
		Modulo:           128,
		IFieldLenRxBytes: pp.Paclen,
		WindowRx:         pp.MaxWindow,
	}
	f := cmdFrame(c.Remote, c.Local, c.Via, ax25.XID, true) // command, P=1
	f.Info = params.Encode(true)                            // command form
	t.sendFrame(c.Port, f)
	c.xidPending = true
}

// negotiateSREJ returns the agreed SREJ mode for the connection: SREJSingle iff
// the port allows SREJ, the link is mod-128, and the peer advertised
// >= SREJSingle; otherwise SREJNone. Mirrors Direwolf's "keep the lower value".
func (t *Table) negotiateSREJ(c *Conn, peerSREJ ax25.SREJMode) ax25.SREJMode {
	if t.portParams(c.Port).SREJ && c.modulo == 128 && peerSREJ >= ax25.SREJSingle {
		return ax25.SREJSingle
	}
	return ax25.SREJNone
}

// dispatchXID handles both XID commands (answerer role) and XID responses
// (initiator role, after sendXIDCommand).
//
// Command (answerer): negotiate SREJ, enable it, and reply with an XID response.
// Mirrors Direwolf xid_frame (mdl_state_0_ready, command branch).
//
// Response (initiator): adopt the negotiated SREJ from the peer's reply; no
// further reply is sent. This is the path triggered after Task 3's sendXIDCommand.
func (t *Table) dispatchXID(port int, f *ax25.Frame, src, dst string) {
	if !t.isLocal(port, dst) {
		return
	}
	c := t.Get(port, dst, src)
	if c == nil {
		return
	}
	their, err := ax25.ParseXID(f.Info)
	if err != nil {
		return
	}

	if !f.Command {
		// Response to our initiated XID command: adopt the negotiated SREJ, no reply.
		// Only act when Connected — an XID response is only valid on an established
		// connection; ignore unsolicited or duplicate responses in other states.
		if c.State != Connected {
			return
		}
		neg := t.negotiateSREJ(c, their.SREJ)
		c.xidPending = false
		c.srejEnabled = neg >= ax25.SREJSingle
		return
	}
	if !f.PF {
		return // command must have P=1
	}

	// Command (answerer role): negotiate, enable, and respond.
	pp := t.portParams(port)
	neg := t.negotiateSREJ(c, their.SREJ)
	c.srejEnabled = neg >= ax25.SREJSingle
	window := pp.MaxWindow
	if their.WindowRx > 0 && their.WindowRx < window {
		window = their.WindowRx
	}
	rsp := ax25.XIDParams{
		FullDuplex:       false,
		SREJ:             neg,
		Modulo:           int(c.modulo),
		IFieldLenRxBytes: pp.Paclen,
		WindowRx:         window,
	}
	out := respFrame(src, dst, c.Via, ax25.XID, true) // response, F=1
	out.Info = rsp.Encode(false)
	t.sendFrame(port, out)
}

// --- helpers ---

// connsByPair returns all connections matching (local, remote) regardless of port,
// keyed by port. Used for overheard-frame checks.
func (t *Table) connsByPair(local, remote string) map[int]*Conn {
	lk := strings.ToUpper(strings.TrimSpace(local))
	rk := strings.ToUpper(strings.TrimSpace(remote))
	out := make(map[int]*Conn)
	for k, c := range t.conns {
		if k.local == lk && k.remote == rk {
			out[k.port] = c
		}
	}
	return out
}

// addrSliceToStrings converts []ax25.Address to []string.
func addrSliceToStrings(addrs []ax25.Address) []string {
	if len(addrs) == 0 {
		return nil
	}
	out := make([]string, len(addrs))
	for i, a := range addrs {
		out[i] = a.String()
	}
	return out
}

// reversed returns a new slice with elements in reverse order.
func reversed(s []string) []string {
	if len(s) == 0 {
		return nil
	}
	out := make([]string, len(s))
	for i, v := range s {
		out[len(s)-1-i] = v
	}
	return out
}
