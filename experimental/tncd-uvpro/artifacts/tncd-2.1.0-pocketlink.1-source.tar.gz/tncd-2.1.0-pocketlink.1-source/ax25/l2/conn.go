// Package l2 implements the AX.25 connected-mode layer-2 state machine.
// All state mutations must occur on the engine loop; callers are responsible
// for posting via engine.Do.
package l2

import (
	"time"

	"github.com/ben-kuhn/tncd/v2/internal/engine"
)

// ConnState represents the AX.25 connection state.
type ConnState int

const (
	Disconnected  ConnState = iota
	Connecting              // SABM sent, awaiting UA
	Connected               // UA received / incoming SABM accepted
	Disconnecting           // DISC sent, awaiting UA
)

func (s ConnState) String() string {
	switch s {
	case Disconnected:
		return "DISCONNECTED"
	case Connecting:
		return "CONNECTING"
	case Connected:
		return "CONNECTED"
	case Disconnecting:
		return "DISCONNECTING"
	}
	return "UNKNOWN"
}

// Conn holds the state for a single AX.25 connected-mode session.
// The key is (Port, Local, Remote) — all uppercase.
// Internal fields mirror the Python Connection dataclass in tncd.py.
type Conn struct {
	Port          int
	Local, Remote string   // uppercase, e.g. "KU0HN-10", "N0CALL-2"
	Via           []string // digipeater path (return direction for outgoing)
	State         ConnState
	Owner         any // opaque; set/read by the frontend

	// Sequence numbers
	modulo    uint8 // 8 (mod-8, default) or 128 (mod-128 / v2.2 extended)
	sendSeq   uint8
	recvSeq   uint8
	unacked   uint8
	lastAcked uint8

	// Outbound queues (Tasks 9-10)
	outQueue      []outEntry
	retransmitBuf map[uint8][]byte

	// Timers
	t1 *engine.Timer
	t2 *engine.Timer
	t3 *engine.Timer

	// T1 state
	t1Polls int
	t1Value time.Duration // current T1, adapted from the Karn/SRTT estimate below

	// RNR/flow control
	remoteBusy bool

	// polling is set while an RR P=1 enquiry awaits its F=1 answer (timer
	// recovery); rejSent while a REJ awaits the frame it asked for (the v2.0
	// reject exception, which allows only one outstanding REJ).
	polling bool
	rejSent bool

	// T2 delayed-ACK state: the peer a deferred RR F=1 is owed.
	t2Src string
	t2Dst string

	incoming bool // true if this connection was remote-initiated

	// v2.2 fallback state
	triedFallback bool // true once a v2.2 connect has downgraded to mod-8

	// SREJ selective repeat (v2.2, phase 3.5)
	xidPending  bool              // we sent an XID command and await its response
	srejEnabled bool              // negotiated SREJ receiver mode active
	rxBuf       map[uint8]rxEntry // out-of-order I-frames keyed by N(S)
	srejSent    map[uint8]bool    // N(S) already requested via SREJ (dedup)

	// Karn RTT estimation: smoothed RTT and variance, updated in ackFrames.
	// Retransmitted I-frames are excluded (Karn's algorithm) so an ambiguous
	// sample cannot poison the estimate.
	srtt   time.Duration
	rttvar time.Duration

	// Per-I-frame send times, consumed to produce one RTT sample per ACK.
	iframeTimestamps map[uint8]time.Time
}

type outEntry struct {
	pid  uint8
	data []byte
}

// rxEntry is a buffered out-of-order I-frame awaiting in-order delivery (SREJ).
type rxEntry struct {
	pid  uint8
	info []byte
}

func newConn(port int, local, remote string) *Conn {
	return &Conn{
		Port:             port,
		Local:            local,
		Remote:           remote,
		State:            Disconnected,
		modulo:           8,
		retransmitBuf:    make(map[uint8][]byte),
		iframeTimestamps: make(map[uint8]time.Time),
		rxBuf:            make(map[uint8]rxEntry),
		srejSent:         make(map[uint8]bool),
	}
}

// cancelTimer cancels a timer if non-nil and returns nil.
func cancelTimer(tm *engine.Timer) *engine.Timer {
	if tm != nil {
		tm.Cancel()
	}
	return nil
}

// resetSeqs zeroes out all sequence counters and clears buffers.
func (c *Conn) resetSeqs() {
	c.sendSeq = 0
	c.recvSeq = 0
	c.unacked = 0
	c.lastAcked = 0
	c.retransmitBuf = make(map[uint8][]byte)
	c.iframeTimestamps = make(map[uint8]time.Time)
	c.outQueue = c.outQueue[:0]
	c.remoteBusy = false
	c.polling = false
	c.rejSent = false
	c.xidPending = false
	c.srejEnabled = false
	c.rxBuf = make(map[uint8]rxEntry)
	c.srejSent = make(map[uint8]bool)
}
