//go:build linux

package kiss

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/godbus/dbus/v5"
	"golang.org/x/sys/unix"
)

// SPP profile UUID for Serial Port Profile.
const sppUUID = "00001101-0000-1000-8000-00805f9b34fb"

// btCallTimeout bounds a single blocking BlueZ D-Bus method call.
//
// godbus's Call blocks until the peer replies, with no deadline of its own. A
// BlueZ that accepts the call but never answers therefore hangs Open()
// forever, and because Open() runs on the port's reconnect path the port stops
// retrying and goes permanently silent with nothing logged — observed live:
// after "already connected, disconnecting first" the port emitted nothing for
// over ten minutes while its siblings kept reconnecting normally, and only a
// restart cleared it.
//
// Every BlueZ call on the connect path is bounded by this instead. It is long
// enough that a busy-but-healthy BlueZ still completes, and short enough that
// a wedged one costs one backoff interval rather than the port.
const btCallTimeout = 15 * time.Second

// dbusCaller is the subset of dbus.BusObject that callBlueZ needs. It exists
// so the timeout behaviour can be tested without a real system bus.
type dbusCaller interface {
	CallWithContext(ctx context.Context, method string, flags dbus.Flags,
		args ...interface{}) *dbus.Call
}

// callBlueZ invokes a BlueZ method, failing with the context error if it does
// not reply within timeout. A prompt reply (success or failure) is returned
// unchanged so callers keep their existing error handling.
func callBlueZ(obj dbusCaller, timeout time.Duration, method string, args ...interface{}) error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	return obj.CallWithContext(ctx, method, 0, args...).Err
}

// profilePath is the D-Bus object path at which we export our Profile1 object.
const profilePath = dbus.ObjectPath("/org/tncd/spp")

// bluetoothTransport implements Transport for a Bluetooth SPP KISS TNC via
// BlueZ D-Bus on Linux.
type bluetoothTransport struct {
	cfg BluetoothConfig

	// mu guards file only. It is NOT held across the actual Read/Write
	// syscalls: those block for as long as the radio takes, and holding a
	// mutex across them would make Close() -- whose whole job is to
	// interrupt a blocked I/O -- wait for the very operation it is trying
	// to unblock. Taking a reference under the lock and then using it
	// unlocked is safe because *os.File is itself concurrency-safe and
	// handles being closed underneath an in-flight call, returning
	// os.ErrClosed rather than touching a reused fd.
	mu   sync.Mutex
	file *os.File // raw OS file wrapping the socket fd

	// txStall tracks how long the socket send queue has been backed up.
	// Touched only by the writer goroutine via Write.
	txStall txStallDetector
}

// NewBluetoothTransport returns a Transport that connects to a Bluetooth SPP
// KISS TNC via BlueZ D-Bus.
func NewBluetoothTransport(cfg BluetoothConfig) Transport {
	return &bluetoothTransport{cfg: cfg}
}

// Open connects to the Bluetooth SPP device.
//
// It registers the SPP Profile1 object on org.bluez (once per process), then
// calls Device1.ConnectProfile asynchronously. BlueZ delivers the connected
// file descriptor via the Profile1.NewConnection D-Bus method call; Open waits
// up to 30 seconds for that to arrive.
//
// Concurrency: ConnectProfile is dispatched via a goroutine so that the
// current goroutine can block on a channel waiting for the fd. godbus spawns
// a new goroutine per incoming call to invoke NewConnection, which writes the
// fd into the pending map and signals the channel. The two goroutines
// communicate via a buffered channel of size 1; there is no shared lock
// required between Open's wait and NewConnection's delivery.
func (bt *bluetoothTransport) Open() error {
	conn, err := dbus.ConnectSystemBus()
	if err != nil {
		return fmt.Errorf("bluetooth: connect to D-Bus system bus: %w", err)
	}
	// We keep the connection alive for the duration of this Open() call.
	// The profile registration is process-scoped and uses its own long-lived
	// connection managed by registerProfileOnce.
	defer conn.Close()

	devicePath, err := bdaddrToPath(bt.cfg.BDAddr)
	if err != nil {
		return err
	}

	// Refuse early if the device is not paired, rather than discovering it
	// from a ConnectProfile that cannot possibly work.
	//
	// An unpaired or absent device answers ConnectProfile with
	// `Method "ConnectProfile" ... doesn't exist`, which says nothing about
	// the actual problem, and the reconnect loop then repeats it forever. A
	// field log had two such ports emitting that plus BlueZ "Host is down"
	// SDP noise every 60s for over an hour, burying the one port that was
	// genuinely misbehaving. ErrNotPaired lets the bridge treat this as the
	// configuration error it is -- see its once-per-port logging.
	if err := checkPaired(conn, devicePath, bt.cfg.BDAddr); err != nil {
		return err
	}

	// Ensure the profile is registered exactly once per process.
	if err := registerProfileOnce(); err != nil {
		return err
	}

	// Register a pending slot for this device before calling ConnectProfile
	// so that an extremely fast delivery from BlueZ is not lost.
	fdCh := make(chan int, 1)
	errCh := make(chan error, 1)
	registerPending(string(devicePath), fdCh)

	// PocketLink experimental build: keep any existing ACL connection and
	// connect the registered SPP profile directly. Full-device disconnects
	// can leave the Cardputer Zero controller waiting for a response.
	// This bypasses upstream's stale-SPP recovery and needs field testing.
	log.Printf("bluetooth: PocketLink experimental: skipping pre-disconnect for %s", bt.cfg.BDAddr)

	// Call ConnectProfile asynchronously so the GLib main loop (or D-Bus
	// dispatcher) can process the incoming NewConnection call while we wait.
	// We use a goroutine + conn.Object.Go to avoid blocking the current
	// goroutine; benign errors are silently swallowed (NoReply, InProgress,
	// br-connection-busy) mirroring tncd.py:800–810.
	deviceObj := conn.Object("org.bluez", devicePath)
	go func() {
		log.Printf("bluetooth: calling ConnectProfile on %s", devicePath)
		call := deviceObj.Call("org.bluez.Device1.ConnectProfile", 0, sppUUID)
		if call.Err != nil {
			if !isBenignConnectError(call.Err) {
				errCh <- fmt.Errorf("bluetooth: ConnectProfile: %w", call.Err)
			}
			// Benign errors are expected: the fd arrives via NewConnection.
		}
	}()

	// Wait for NewConnection to deliver the fd (or a fatal error), up to 30s.
	select {
	case fd := <-fdCh:
		// NewConnection has already dup'd or taken ownership; wrap as *os.File.
		bt.mu.Lock()
		bt.file = os.NewFile(uintptr(fd), fmt.Sprintf("bt-spp-%s", bt.cfg.BDAddr))
		bt.mu.Unlock()
		// Fresh socket, fresh queue: clear any stall clock left from a previous
		// link so a reopened transport cannot trip on the old one's backlog.
		bt.txStall = txStallDetector{}
		log.Printf("bluetooth: SPP socket ready (fd=%d) for %s", fd, bt.cfg.BDAddr)
		// Drop any Bluetooth audio profiles now that SPP is up. On some radios
		// (notably the UV-PRO) an active audio profile — auto-connected by the
		// desktop/BlueZ, often on a radio power-cycle — corrupts the SPP/KISS
		// data channel: writes complete at the socket but frames never reach the
		// TNC. Runs on every connect and reconnect (Open is called for both).
		disconnectAudioProfiles(deviceObj, bt.cfg.BDAddr)
		return nil
	case err := <-errCh:
		removePending(string(devicePath))
		return err
	case <-time.After(30 * time.Second):
		removePending(string(devicePath))
		return fmt.Errorf("bluetooth: connection to %s timed out (30s)", bt.cfg.BDAddr)
	}
}

// ControlChannel returns the Benshi rig-control channel for this transport.
//
// There is no second RFCOMM link to dial: confirmed live against a UV-PRO
// (2026-09-23), the radio's Gaia command protocol is served on the SAME
// RFCOMM connection as KISS traffic ("SPP Dev"). A separate "BS AOC" service
// (channel 2) exists on the radio's SDP record, accepts a connection, and
// then answers nothing, ever -- an earlier version of this method dialled
// that service via its own Profile1 registration at /org/tncd/control; it is
// gone. A Gaia request written straight to the already-open KISS socket gets
// a real reply, and KISS/Gaia frames were shown to interleave cleanly on the
// wire (two independent KISS frames plus a Gaia reply, confirmed on-air by a
// separate Dire Wolf receiver), distinguished only by their leading bytes
// (KISS: 0xC0, Gaia: 0xFF 0x01) -- never by which socket they arrived on,
// because there is only one.
//
// Sharp edge: the returned channel and bt's own KISS reader both read from
// this one byte stream. Today that is safe because the only consumer is the
// one-shot `tncd rig` CLI, which opens the transport and runs no KISS reader
// of its own. It will NOT be safe for rig control running alongside a live
// KISS port -- that needs a demultiplexer (one reader owning the stream,
// routing 0xC0 to the KISS decoder and 0xFF 0x01 to the rig layer) in front
// of both consumers. Built in kiss/demux.go.
func (bt *bluetoothTransport) ControlChannel() (io.ReadWriteCloser, error) {
	if bt.handle() == nil {
		return nil, fmt.Errorf("bluetooth: not open")
	}
	return &selfControlChannel{ReadWriteCloser: bt}, nil
}

// handle returns the current socket file, or nil when the transport is not
// open. Callers use the returned value rather than re-reading bt.file, so a
// concurrent Close cannot nil it out between the check and the use.
func (bt *bluetoothTransport) handle() *os.File {
	bt.mu.Lock()
	defer bt.mu.Unlock()
	return bt.file
}

// bluetoothReconnectSettle is how long Open waits after disconnecting a stale
// connection before calling ConnectProfile, so BlueZ and the peer fully tear
// down the old RFCOMM link rather than handing back a wedged half-open channel.
const bluetoothReconnectSettle = 2 * time.Second

// audioProfileUUIDs are the Bluetooth Classic audio profiles we drop after
// establishing SPP. When one of these is connected alongside SPP, the RFCOMM
// data channel becomes unreliable on some radios (writes succeed at the socket
// but frames never reach the TNC's transmitter).
var audioProfileUUIDs = []string{
	"0000111e-0000-1000-8000-00805f9b34fb", // Handsfree (HFP HF)
	"0000111f-0000-1000-8000-00805f9b34fb", // Handsfree Audio Gateway (HFP AG)
	"0000110b-0000-1000-8000-00805f9b34fb", // A2DP Sink
	"0000110a-0000-1000-8000-00805f9b34fb", // A2DP Source
	"0000110d-0000-1000-8000-00805f9b34fb", // Advanced Audio Distribution
	"0000110e-0000-1000-8000-00805f9b34fb", // A/V Remote Control
}

// disconnectAudioProfiles asks BlueZ to disconnect each audio profile on the
// device, leaving SPP intact. Errors (profile not connected / not supported)
// are expected and ignored; only successful drops are logged.
func disconnectAudioProfiles(deviceObj dbus.BusObject, bdaddr string) {
	for _, uuid := range audioProfileUUIDs {
		if err := callBlueZ(deviceObj, btCallTimeout,
			"org.bluez.Device1.DisconnectProfile", uuid); err == nil {
			log.Printf("bluetooth: %s dropped audio profile %s", bdaddr, uuid)
		}
	}
}

func (bt *bluetoothTransport) Read(b []byte) (int, error) {
	f := bt.handle()
	if f == nil {
		return 0, fmt.Errorf("bluetooth: not open")
	}
	return f.Read(b)
}

// What this detector can and cannot see
//
// It watches ONE layer: the host's own socket send queue. That covers the case
// where the peer stops granting RFCOMM credits — the kernel then cannot hand
// the bytes over, they pile up in our send buffer, and the depth below grows
// until this trips.
//
// It does NOT cover a radio that accepts the bytes and then sits on them, and
// the field evidence says to expect exactly that. Over two minutes of a real
// UV-PRO stall (2026-09-11, frames written at 21:58:42 that an independent air
// monitor did not hear until 22:00:49 — 126s later) every write returned the
// full byte count in 4-21 microseconds and the depth below read ZERO. Sampled
// across 61 writes in that session the queue was empty for 42 of them and
// otherwise held only the transient single-frame values. The bytes left the
// host promptly; the radio buffered them. Nothing observable from this side of
// the socket changes during such a stall, so do not read a quiet detector as
// evidence that TX is healthy.
//
// The layer that CAN see the radio-side case is the bridge's read-side wedge
// watchdog (rx_wedge_timeout): it notices that nothing is coming back while TX
// is outstanding, which is the only host-visible symptom a buffering radio
// produces. Classic SPP has no delivery acknowledgement, so per-frame proof is
// impossible here by construction; a BLE GATT write-with-response is the
// transport-level fix, since that ack originates at the radio.

// txStallTimeout is how long the send queue may stay continuously backed up
// before the TX path is declared stalled. KISS frames are small and the
// Bluetooth link is far faster than 1200-baud RF, so in normal operation the
// kernel hands each frame to the radio in milliseconds and the queue reads
// empty between writes. A queue that stays backed up for this long is not
// congestion, it is a link that has stopped draining. The value sits above the
// L2 T1 poll interval so an ordinary retransmit cycle cannot trip it, and below
// the peer's own give-up time so the port is cycled while the session is still
// worth saving.
const txStallTimeout = 30 * time.Second

// txStallDetector tracks how long the socket send queue has been continuously
// backed up. Only the writer goroutine touches it, so it needs no lock.
type txStallDetector struct {
	since time.Time
}

// observe records a send-queue depth sample and returns how long the queue has
// been continuously backed up. A drained queue clears the tracking, so the
// duration only grows while bytes are genuinely stuck.
func (d *txStallDetector) observe(depth int, now time.Time) time.Duration {
	if depth <= 0 {
		d.since = time.Time{}
		return 0
	}
	if d.since.IsZero() {
		d.since = now
		return 0
	}
	return now.Sub(d.since)
}

// txQueueDepth reports how many bytes the kernel has accepted from us but not
// yet delivered to the peer.
//
// Bluetooth sockets answer TIOCOUTQ with the *free* space in the send buffer
// (net/bluetooth/af_bluetooth.c returns sk_sndbuf - sk_wmem_alloc), which is
// the opposite of the TCP convention, so the depth is recovered by subtracting
// from SO_SNDBUF. Read via SyscallConn rather than File.Fd(): Fd() puts the
// descriptor into blocking mode and removes it from the runtime poller, which
// would change how every subsequent read and write behaves.
func (bt *bluetoothTransport) txQueueDepth() (int, error) {
	f := bt.handle()
	if f == nil {
		return 0, fmt.Errorf("bluetooth: not open")
	}
	rc, err := f.SyscallConn()
	if err != nil {
		return 0, err
	}
	var depth int
	var inner error
	if err := rc.Control(func(fd uintptr) {
		free, e := unix.IoctlGetInt(int(fd), unix.TIOCOUTQ)
		if e != nil {
			inner = e
			return
		}
		sndbuf, e := unix.GetsockoptInt(int(fd), unix.SOL_SOCKET, unix.SO_SNDBUF)
		if e != nil {
			inner = e
			return
		}
		if d := sndbuf - free; d > 0 {
			depth = d
		}
	}); err != nil {
		return 0, err
	}
	return depth, inner
}

// checkTXDrain fails the write when our send queue has been backed up for
// txStallTimeout, i.e. the kernel has bytes for the radio that it cannot hand
// over. Returning an error routes it through the port's normal teardown, taking
// the port offline for a reconnect. See the txStallTimeout comment for why this
// covers only credit starvation and not a radio that buffers internally.
//
// Sampled *before* handing over the next frame, so it measures whether earlier
// frames drained. Sampling afterwards would always count the bytes just
// written — measured at ~960 on a healthy link for a 27-byte KISS frame, since
// the depth includes socket-buffer overhead for the frame still in flight —
// and the queue would never appear empty, tripping this on a working link.
//
// Only Write samples this, which is sufficient for the failure it targets: a
// starved link still has L2 pushing T1 polls and retransmits into it, so
// samples keep arriving for as long as anything is worth transmitting.
//
// If the query itself fails the write is left alone: no detection is better
// than refusing to transmit on a link that may be perfectly healthy.
func (bt *bluetoothTransport) checkTXDrain() error {
	depth, err := bt.txQueueDepth()
	if err != nil {
		return nil
	}
	if stalled := bt.txStall.observe(depth, time.Now()); stalled >= txStallTimeout {
		return fmt.Errorf("bluetooth: TX stalled -- %d bytes stuck in the host send queue for %s, "+
			"%s is not accepting data", depth, stalled.Round(time.Second), bt.cfg.BDAddr)
	}
	return nil
}

func (bt *bluetoothTransport) Write(b []byte) (int, error) {
	f := bt.handle()
	if f == nil {
		return 0, fmt.Errorf("bluetooth: not open")
	}
	// Check the backlog before adding to it: a write "succeeding" here only
	// means the kernel accepted the bytes, so the question that matters is
	// whether everything written earlier actually drained to the radio. Bail
	// out rather than queueing behind them — the port is about to be torn down,
	// and piling another frame onto a queue we have just declared dead can only
	// block us in the kernel.
	if err := bt.checkTXDrain(); err != nil {
		return 0, err
	}

	return f.Write(b)
}

func (bt *bluetoothTransport) Close() error {
	bt.mu.Lock()
	f := bt.file
	bt.file = nil
	bt.mu.Unlock()
	if f == nil {
		return nil
	}
	// Closed outside the lock, deliberately: closing interrupts any Read or
	// Write currently blocked in a syscall on this fd (Go's runtime poller
	// does this for pollable fds), and those calls are holding no lock, so
	// there is nothing for this to contend with.
	return f.Close()
}

// EnterKISS is a no-op: Bluetooth SPP TNCs (Mobilinkd) are always in KISS mode.
func (bt *bluetoothTransport) EnterKISS() error { return nil }

// ExitKISS is a no-op: KISS exit bytes are serial-only (tncd.py:916).
func (bt *bluetoothTransport) ExitKISS() {}

// ---- Process-scoped profile registration ----

// sppProfile is the exported D-Bus object that BlueZ calls back on.
// Its methods are invoked by godbus in a new goroutine per incoming call.
type sppProfile struct{}

// NewConnection is called by BlueZ when a connected fd is ready for the
// registered SPP profile. godbus transfers ownership of the delivered fd to
// this method; we route it to the waiting Open() call via the pending map.
// If the connection is unexpected or the channel is full, we close the fd here.
func (p *sppProfile) NewConnection(devicePath dbus.ObjectPath, fd dbus.UnixFD, properties map[string]dbus.Variant) *dbus.Error {
	rawFD := int(fd)
	log.Printf("bluetooth: NewConnection: path=%s fd=%d", devicePath, rawFD)

	fdCh := lookupPending(string(devicePath))
	if fdCh == nil {
		log.Printf("bluetooth: unexpected NewConnection from %s, closing fd", devicePath)
		_ = closeFD(rawFD)
		return nil
	}
	// Non-blocking send: channel is buffered(1) and Open created it just for us.
	select {
	case fdCh <- rawFD:
	default:
		log.Printf("bluetooth: fd channel full for %s, closing fd", devicePath)
		_ = closeFD(rawFD)
	}
	return nil
}

// RequestDisconnection is called by BlueZ when a device disconnects.
// Log-only per tncd.py:961–963.
func (p *sppProfile) RequestDisconnection(devicePath dbus.ObjectPath) *dbus.Error {
	log.Printf("bluetooth: RequestDisconnection: %s", devicePath)
	return nil
}

// Release is called by BlueZ when the profile is unregistered.
// Log-only per tncd.py:965–969.
func (p *sppProfile) Release() *dbus.Error {
	log.Printf("bluetooth: SPP profile released by BlueZ")
	return nil
}

// profileConn owns the D-Bus connection the Profile1 object is exported on.
// BlueZ calls back into that object (NewConnection) for the life of the
// process, so the connection must stay open; this package-level reference is
// what keeps it from being collected. Write-only by design — nothing reads it
// back, it exists purely to own the handle.
//
//lint:ignore U1000 keep-alive reference; see above
var profileConn *dbus.Conn

// profileMu guards profileRegistered and profileConn.
var profileMu sync.Mutex

// profileRegistered is true once a successful RegisterProfile call has been
// made. Unlike sync.Once, a failed attempt leaves it false so the next
// Open() can retry from scratch.
var profileRegistered bool

// registerProfileOnce connects to the system D-Bus, exports the Profile1
// object, and calls ProfileManager1.RegisterProfile.
//
// On success it sets profileRegistered=true and leaves profileConn open for
// the lifetime of the profile. On failure it closes any D-Bus connection
// opened during this attempt and returns the error, leaving profileRegistered
// false so the next call retries.
//
// Once registration succeeds, subsequent calls are no-ops (idempotent).
func registerProfileOnce() error {
	return ensureProfile(func() error {
		conn, err := dbus.ConnectSystemBus()
		if err != nil {
			return fmt.Errorf("bluetooth: system bus for profile: %w", err)
		}

		prof := &sppProfile{}
		// Export using ExportMethodTable so we can map D-Bus method names
		// (with dots and mixed case) to Go methods.
		err = conn.ExportMethodTable(
			map[string]interface{}{
				"NewConnection":        prof.NewConnection,
				"RequestDisconnection": prof.RequestDisconnection,
				"Release":              prof.Release,
			},
			profilePath,
			"org.bluez.Profile1",
		)
		if err != nil {
			conn.Close()
			return fmt.Errorf("bluetooth: export Profile1: %w", err)
		}

		manager := conn.Object("org.bluez", "/org/bluez")
		opts := map[string]dbus.Variant{
			"Role": dbus.MakeVariant("client"),
		}
		if err := callBlueZ(manager, btCallTimeout,
			"org.bluez.ProfileManager1.RegisterProfile",
			profilePath, sppUUID, opts,
		); err != nil {
			conn.Close()
			// "Already Exists" means another process on this machine has
			// already registered the SPP profile at this path -- almost
			// always a running tncd. Saying so beats reporting a D-Bus
			// detail the operator cannot act on: two processes genuinely
			// cannot share one Bluetooth link, so the answer is to stop the
			// other instance, or to reach the radio through its rigctl
			// listener instead of the one-shot CLI.
			// BlueZ reports this as org.bluez.Error.AlreadyExists with the
			// message "UUID already registered"; match both shapes rather
			// than one, since the wording is not API.
			low := strings.ToLower(err.Error())
			if strings.Contains(low, "alreadyexists") ||
				strings.Contains(low, "already exists") ||
				strings.Contains(low, "already registered") {
				return fmt.Errorf("bluetooth: the SPP profile at %s is already registered, "+
					"which means another tncd is running and holding this radio -- "+
					"stop it first, or use its [rigctl.N] listener to reach the radio: %w",
					profilePath, err)
			}
			return fmt.Errorf("bluetooth: RegisterProfile: %w", err)
		}

		profileConn = conn
		log.Printf("bluetooth: SPP profile registered at %s", profilePath)
		return nil
	})
}

// ensureProfile is the testable seam for profile registration. It calls
// register at most once as long as registration keeps failing; once register
// succeeds the registered flag is set and subsequent calls are no-ops.
//
// Thread-safe: guarded by profileMu.
func ensureProfile(register func() error) error {
	profileMu.Lock()
	defer profileMu.Unlock()
	if profileRegistered {
		return nil
	}
	if err := register(); err != nil {
		// Leave profileRegistered false so the next Open() can retry.
		return err
	}
	profileRegistered = true
	return nil
}

// ---- Pending-connection map ----

var pendingMu sync.Mutex
var pendingMap = map[string]chan int{}

func registerPending(devicePath string, ch chan int) {
	pendingMu.Lock()
	pendingMap[devicePath] = ch
	pendingMu.Unlock()
}

func removePending(devicePath string) {
	pendingMu.Lock()
	delete(pendingMap, devicePath)
	pendingMu.Unlock()
}

func lookupPending(devicePath string) chan int {
	pendingMu.Lock()
	ch := pendingMap[devicePath]
	if ch != nil {
		delete(pendingMap, devicePath)
	}
	pendingMu.Unlock()
	return ch
}

// ---- Helpers ----

// bdaddrToPath converts a Bluetooth address (AA:BB:CC:DD:EE:FF) to the BlueZ
// D-Bus device path (/org/bluez/hci0/dev_AA_BB_CC_DD_EE_FF).
func bdaddrToPath(bdaddr string) (dbus.ObjectPath, error) {
	if bdaddr == "" {
		return "", fmt.Errorf("bluetooth: bdaddr is empty")
	}
	escaped := strings.ToUpper(strings.ReplaceAll(bdaddr, ":", "_"))
	return dbus.ObjectPath("/org/bluez/hci0/dev_" + escaped), nil
}

// isDeviceConnected reads the Connected property from a BlueZ Device1 object.
// Bounded by btCallTimeout: this runs on the connect path, where an unanswered
// call would wedge the port's reconnect loop.
func isDeviceConnected(obj dbus.BusObject) (bool, error) {
	ctx, cancel := context.WithTimeout(context.Background(), btCallTimeout)
	defer cancel()
	var v dbus.Variant
	err := obj.CallWithContext(ctx, "org.freedesktop.DBus.Properties.Get", 0,
		"org.bluez.Device1", "Connected").Store(&v)
	if err != nil {
		return false, err
	}
	connected, ok := v.Value().(bool)
	return ok && connected, nil
}

// isBenignConnectError returns true for errors that are expected when BlueZ
// delivers the fd via NewConnection rather than the ConnectProfile reply.
// Mirrors tncd.py:800–804.
func isBenignConnectError(err error) bool {
	s := err.Error()
	return strings.Contains(s, "NoReply") ||
		strings.Contains(s, "Did not receive a reply") ||
		strings.Contains(s, "InProgress") ||
		strings.Contains(s, "br-connection-busy")
}

// closeFD closes a raw file descriptor.
func closeFD(fd int) error {
	return syscall.Close(fd)
}

// ErrNotPaired reports a configured Bluetooth device that BlueZ does not know
// about, or knows about but has not paired. It is a configuration problem,
// not a transient one: retrying cannot fix it without a human pairing the
// radio, so callers should say so once rather than every retry.
var ErrNotPaired = errors.New("bluetooth: device is not paired")

// checkPaired reports whether BlueZ has this device and considers it paired.
//
// A missing device object and an unpaired one are reported the same way on
// purpose: both mean "pair this radio before tncd can use it", and both
// otherwise surface as the same unhelpful ConnectProfile error.
func checkPaired(conn *dbus.Conn, devicePath dbus.ObjectPath, addr string) error {
	obj := conn.Object("org.bluez", devicePath)
	v, err := obj.GetProperty("org.bluez.Device1.Paired")
	if err != nil {
		return fmt.Errorf("%w: BlueZ has no device object for %s "+
			"(pair it first, e.g. `bluetoothctl pair %s`, or remove the port from the config): %v",
			ErrNotPaired, addr, addr, err)
	}
	paired, ok := v.Value().(bool)
	if !ok {
		// Unexpected property type: don't block the connect over it.
		return nil
	}
	if !paired {
		return fmt.Errorf("%w: %s is known to BlueZ but not paired "+
			"(run `bluetoothctl pair %s`, or remove the port from the config)",
			ErrNotPaired, addr, addr)
	}
	return nil
}
