# Experimental PocketLink tncd build

This separately named build of tncd 2.1.0 skips a whole-device Bluetooth
disconnect immediately before SPP connection. It is an experiment for the
Cardputer Zero and has not been validated on the radio. Upstream included that
disconnect to clear stale SPP links, so this change may leave a connection that
appears online but does not transmit. The build retains upstream's subsequent
audio-profile disconnect behavior.

The upstream source is commit `5180db276f8f922cd90db7f68e067a28be8dc515`
from <https://github.com/ben-kuhn/tncd> (the commit behind tag `v2.1.0`).
It is licensed under GPL-3.0; the complete source, including COPYING, is
available at `https://codeload.github.com/ben-kuhn/tncd/tar.gz/5180db276f8f922cd90db7f68e067a28be8dc515`.
Its SHA-256 is `92421ca0cf22d92b12482a3b5eb77f5e8e82f85def16f2b0b2e1cf2fbe24bc75`.
The exact corresponding modification is expressed in `build.py`, which checks
that hash and applies the source transformation before building.

With Python 3, Go 1.25.13 or newer, and network access for Go dependencies:

```sh
python3 build.py --arch arm64 --output ./tncd-2.1.0-pocketlink.1-linux-arm64
```

The script downloads and checks the upstream source, builds in a temporary
directory, and refuses to overwrite an existing output. A previously acquired
upstream source archive may be passed with `--archive`. Build an amd64 test
executable by specifying `--arch amd64`. The executable is separate from the
official `tncd`; restoring the original means selecting the original executable.
